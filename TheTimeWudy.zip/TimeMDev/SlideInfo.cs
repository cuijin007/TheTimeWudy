﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimeMDev
{
    public class SlideInfo
    {
        public int startPosition;
        public int endPosition;
        public int num;//存储在那个List中的位置
    }
}
