﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimeMDev
{
    public class AddMutiLinesParameter
    {
        public bool isConfirm;
        public double timeSpiltLength;
        public int lineCount;
        public bool isBlank;
    }
}
