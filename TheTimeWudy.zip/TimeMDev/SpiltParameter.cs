﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimeMDev
{
    public class SpiltParameter
    {
        public string beforeSpilt;
        public string[] afterSpiltFristLine;
        public string[] afterSpiltSecondLine;
        public bool isDoubleLanguage;
        public double timeLength;
        public bool confirm;
    }
}
