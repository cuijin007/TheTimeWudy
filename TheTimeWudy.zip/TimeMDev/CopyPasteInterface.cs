﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimeMDev
{
    public interface CopyPasteInterface
    {
        void _Copy();
        void _Paste();
    }
}
