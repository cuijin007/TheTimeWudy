﻿namespace TimeMDev
{
    partial class MovieControlPanel
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MovieControlPanel));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLoadFile = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripPlay = new System.Windows.Forms.ToolStripButton();
            this.toolStripPause = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripBack5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripForward5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripBack10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripForward10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStrip1Step = new System.Windows.Forms.ToolStripButton();
            this.toolStripSyn = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripPanel1 = new System.Windows.Forms.ToolStripPanel();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripAlignNow = new System.Windows.Forms.ToolStripButton();
            this.toolStripAlignAfter = new System.Windows.Forms.ToolStripButton();
            this.toolStripAlighAll = new System.Windows.Forms.ToolStripButton();
            this.toolStripAlighStart = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripAlighEnd = new System.Windows.Forms.ToolStripButton();
            this.toolStripAddOne = new System.Windows.Forms.ToolStripButton();
            this.toolStripAddMuti = new System.Windows.Forms.ToolStripButton();
            this.toolStripSaveAuto = new System.Windows.Forms.ToolStripButton();
            this.toolStripSign = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStrip1.SuspendLayout();
            this.toolStripPanel1.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLoadFile,
            this.toolStripSeparator1,
            this.toolStripPlay,
            this.toolStripPause,
            this.toolStripSeparator2,
            this.toolStripBack5,
            this.toolStripForward5,
            this.toolStripBack10,
            this.toolStripForward10,
            this.toolStripSeparator3,
            this.toolStrip1Step,
            this.toolStripSyn,
            this.toolStripSeparator4});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(232, 23);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLoadFile
            // 
            this.toolStripLoadFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripLoadFile.Image = ((System.Drawing.Image)(resources.GetObject("toolStripLoadFile.Image")));
            this.toolStripLoadFile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripLoadFile.Name = "toolStripLoadFile";
            this.toolStripLoadFile.Size = new System.Drawing.Size(23, 20);
            this.toolStripLoadFile.Text = "toolStripButton1";
            this.toolStripLoadFile.ToolTipText = "打开";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStripPlay
            // 
            this.toolStripPlay.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripPlay.Image = ((System.Drawing.Image)(resources.GetObject("toolStripPlay.Image")));
            this.toolStripPlay.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripPlay.Name = "toolStripPlay";
            this.toolStripPlay.Size = new System.Drawing.Size(23, 20);
            this.toolStripPlay.Text = "toolStripButton2";
            this.toolStripPlay.ToolTipText = "播放";
            // 
            // toolStripPause
            // 
            this.toolStripPause.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripPause.Image = ((System.Drawing.Image)(resources.GetObject("toolStripPause.Image")));
            this.toolStripPause.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripPause.Name = "toolStripPause";
            this.toolStripPause.Size = new System.Drawing.Size(23, 20);
            this.toolStripPause.Text = "toolStripButton3";
            this.toolStripPause.ToolTipText = "暂停";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStripBack5
            // 
            this.toolStripBack5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripBack5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripBack5.Image")));
            this.toolStripBack5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripBack5.Name = "toolStripBack5";
            this.toolStripBack5.Size = new System.Drawing.Size(23, 20);
            this.toolStripBack5.Text = "toolStripButton4";
            this.toolStripBack5.ToolTipText = "快退5S";
            // 
            // toolStripForward5
            // 
            this.toolStripForward5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripForward5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripForward5.Image")));
            this.toolStripForward5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripForward5.Name = "toolStripForward5";
            this.toolStripForward5.Size = new System.Drawing.Size(23, 20);
            this.toolStripForward5.Text = "快进5S";
            // 
            // toolStripBack10
            // 
            this.toolStripBack10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripBack10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripBack10.Image")));
            this.toolStripBack10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripBack10.Name = "toolStripBack10";
            this.toolStripBack10.Size = new System.Drawing.Size(23, 20);
            this.toolStripBack10.Text = "快退10S";
            // 
            // toolStripForward10
            // 
            this.toolStripForward10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripForward10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripForward10.Image")));
            this.toolStripForward10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripForward10.Name = "toolStripForward10";
            this.toolStripForward10.Size = new System.Drawing.Size(23, 20);
            this.toolStripForward10.Text = "快进10S";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStrip1Step
            // 
            this.toolStrip1Step.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStrip1Step.Image = ((System.Drawing.Image)(resources.GetObject("toolStrip1Step.Image")));
            this.toolStrip1Step.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStrip1Step.Name = "toolStrip1Step";
            this.toolStrip1Step.Size = new System.Drawing.Size(23, 20);
            this.toolStrip1Step.Text = "下一帧";
            // 
            // toolStripSyn
            // 
            this.toolStripSyn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSyn.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSyn.Image")));
            this.toolStripSyn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSyn.Name = "toolStripSyn";
            this.toolStripSyn.Size = new System.Drawing.Size(23, 20);
            this.toolStripSyn.Text = "同步";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStripPanel1
            // 
            this.toolStripPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.toolStripPanel1.Controls.Add(this.toolStrip1);
            this.toolStripPanel1.Controls.Add(this.toolStrip2);
            this.toolStripPanel1.Location = new System.Drawing.Point(26, 139);
            this.toolStripPanel1.Name = "toolStripPanel1";
            this.toolStripPanel1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.toolStripPanel1.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.toolStripPanel1.Size = new System.Drawing.Size(477, 30);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripAlignNow,
            this.toolStripAlignAfter,
            this.toolStripAlighAll,
            this.toolStripSeparator5,
            this.toolStripAlighStart,
            this.toolStripAlighEnd,
            this.toolStripSeparator6,
            this.toolStripAddOne,
            this.toolStripAddMuti,
            this.toolStripSeparator7,
            this.toolStripSaveAuto,
            this.toolStripSign});
            this.toolStrip2.Location = new System.Drawing.Point(235, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(237, 25);
            this.toolStrip2.TabIndex = 1;
            // 
            // toolStripAlignNow
            // 
            this.toolStripAlignNow.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlignNow.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlignNow.Image")));
            this.toolStripAlignNow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlignNow.Name = "toolStripAlignNow";
            this.toolStripAlignNow.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlignNow.Text = "将播放器的时间同步到此时间轴";
            // 
            // toolStripAlignAfter
            // 
            this.toolStripAlignAfter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlignAfter.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlignAfter.Image")));
            this.toolStripAlignAfter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlignAfter.Name = "toolStripAlignAfter";
            this.toolStripAlignAfter.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlignAfter.Text = "以当前的播放器时间对其以后的时间";
            // 
            // toolStripAlighAll
            // 
            this.toolStripAlighAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlighAll.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlighAll.Image")));
            this.toolStripAlighAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlighAll.Name = "toolStripAlighAll";
            this.toolStripAlighAll.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlighAll.Text = "以现在播放器时间对其所有时间";
            // 
            // toolStripAlighStart
            // 
            this.toolStripAlighStart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlighStart.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlighStart.Image")));
            this.toolStripAlighStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlighStart.Name = "toolStripAlighStart";
            this.toolStripAlighStart.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlighStart.Text = "对其开始时间";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripAlighEnd
            // 
            this.toolStripAlighEnd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlighEnd.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlighEnd.Image")));
            this.toolStripAlighEnd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlighEnd.Name = "toolStripAlighEnd";
            this.toolStripAlighEnd.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlighEnd.Text = "对其结束时间";
            // 
            // toolStripAddOne
            // 
            this.toolStripAddOne.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAddOne.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAddOne.Image")));
            this.toolStripAddOne.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAddOne.Name = "toolStripAddOne";
            this.toolStripAddOne.Size = new System.Drawing.Size(23, 22);
            this.toolStripAddOne.Text = "增加一行";
            // 
            // toolStripAddMuti
            // 
            this.toolStripAddMuti.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAddMuti.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAddMuti.Image")));
            this.toolStripAddMuti.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAddMuti.Name = "toolStripAddMuti";
            this.toolStripAddMuti.Size = new System.Drawing.Size(23, 22);
            this.toolStripAddMuti.Text = "增加多行";
            // 
            // toolStripSaveAuto
            // 
            this.toolStripSaveAuto.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSaveAuto.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSaveAuto.Image")));
            this.toolStripSaveAuto.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSaveAuto.Name = "toolStripSaveAuto";
            this.toolStripSaveAuto.Size = new System.Drawing.Size(23, 22);
            this.toolStripSaveAuto.Text = "自动保存";
            // 
            // toolStripSign
            // 
            this.toolStripSign.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSign.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSign.Image")));
            this.toolStripSign.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSign.Name = "toolStripSign";
            this.toolStripSign.Size = new System.Drawing.Size(23, 20);
            this.toolStripSign.Text = "toolStripButton14";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // MovieControlPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.toolStripPanel1);
            this.Name = "MovieControlPanel";
            this.Size = new System.Drawing.Size(661, 393);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStripPanel1.ResumeLayout(false);
            this.toolStripPanel1.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripLoadFile;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripPlay;
        private System.Windows.Forms.ToolStripButton toolStripPause;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripBack5;
        private System.Windows.Forms.ToolStripButton toolStripForward5;
        private System.Windows.Forms.ToolStripButton toolStripBack10;
        private System.Windows.Forms.ToolStripButton toolStripForward10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStrip1Step;
        private System.Windows.Forms.ToolStripButton toolStripSyn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripPanel toolStripPanel1;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton toolStripAlignNow;
        private System.Windows.Forms.ToolStripButton toolStripAlignAfter;
        private System.Windows.Forms.ToolStripButton toolStripAlighAll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripAlighStart;
        private System.Windows.Forms.ToolStripButton toolStripAlighEnd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolStripAddOne;
        private System.Windows.Forms.ToolStripButton toolStripAddMuti;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton toolStripSaveAuto;
        private System.Windows.Forms.ToolStripButton toolStripSign;



    }
}
