﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimeMDev
{
    /// <summary>
    /// 操作基类，定义了重载和
    /// </summary>
    public abstract class HandleRecordBass
    {
        public abstract void Execute();
        public abstract void UnExecute();
    }
}
