﻿namespace TimeMDev
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dockManager1 = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.dockPanel1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.navBarControl1 = new DevExpress.XtraNavBar.NavBarControl();
            this.navBarGroup1 = new DevExpress.XtraNavBar.NavBarGroup();
            this.openSubtitleLink = new DevExpress.XtraNavBar.NavBarItem();
            this.openVideoLink = new DevExpress.XtraNavBar.NavBarItem();
            this.newSubtitleLink = new DevExpress.XtraNavBar.NavBarItem();
            this.loadTxtLink = new DevExpress.XtraNavBar.NavBarItem();
            this.addSubtitleLink = new DevExpress.XtraNavBar.NavBarItem();
            this.ccHandleLink = new DevExpress.XtraNavBar.NavBarItem();
            this.exportSubtitleItem = new DevExpress.XtraNavBar.NavBarItem();
            this.saveSubtitleLink = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup2 = new DevExpress.XtraNavBar.NavBarGroup();
            this.merageToEndLink = new DevExpress.XtraNavBar.NavBarItem();
            this.merageToNewLink = new DevExpress.XtraNavBar.NavBarItem();
            this.cutLineLink = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup3 = new DevExpress.XtraNavBar.NavBarGroup();
            this.alignNowLineLink = new DevExpress.XtraNavBar.NavBarItem();
            this.alignNextLineLink = new DevExpress.XtraNavBar.NavBarItem();
            this.alignAllLineLink = new DevExpress.XtraNavBar.NavBarItem();
            this.alignToBeforeSignLink = new DevExpress.XtraNavBar.NavBarItem();
            this.alignToAfterSignLink = new DevExpress.XtraNavBar.NavBarItem();
            this.translationTimeLink = new DevExpress.XtraNavBar.NavBarItem();
            this.mergeTwoLanLink = new DevExpress.XtraNavBar.NavBarItem();
            this.findErrorLink = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup4 = new DevExpress.XtraNavBar.NavBarGroup();
            this.startMplayerFristTimeLink = new DevExpress.XtraNavBar.NavBarItem();
            this.panelContainer1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.videoPanel = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel3_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.videoPlayPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.nowTimeLineShow = new System.Windows.Forms.Label();
            this.movieTrack = new System.Windows.Forms.TrackBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.toolStripPanel1 = new System.Windows.Forms.ToolStripPanel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLoadFile = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripPlay = new System.Windows.Forms.ToolStripButton();
            this.toolStripPause = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripBack5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripForward5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripBack10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripForward10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStrip1Step = new System.Windows.Forms.ToolStripButton();
            this.toolStripSyn = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripAlignNow = new System.Windows.Forms.ToolStripButton();
            this.toolStripAlignAfter = new System.Windows.Forms.ToolStripButton();
            this.toolStripAlighAll = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripAlighStart = new System.Windows.Forms.ToolStripButton();
            this.toolStripAlighEnd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripAddOne = new System.Windows.Forms.ToolStripButton();
            this.toolStripAddMuti = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSaveAuto = new System.Windows.Forms.ToolStripButton();
            this.toolStripSign = new System.Windows.Forms.ToolStripButton();
            this.toolStripSync = new System.Windows.Forms.ToolStripButton();
            this.modifySubtitlePanel = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel4_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.contentEdit = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.confirmChange = new System.Windows.Forms.Button();
            this.timeEditStart = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timeEditEnd = new System.Windows.Forms.TextBox();
            this.numEdit = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.picTimeLinePanel = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel2_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.rateShow = new System.Windows.Forms.PictureBox();
            this.nowTimeShow = new System.Windows.Forms.Label();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.fileMenu = new DevExpress.XtraBars.BarSubItem();
            this.newSubtitleItem = new DevExpress.XtraBars.BarButtonItem();
            this.loadSubtitleItem = new DevExpress.XtraBars.BarButtonItem();
            this.loadTranslationItem = new DevExpress.XtraBars.BarButtonItem();
            this.addSubtitleItem = new DevExpress.XtraBars.BarButtonItem();
            this.saveSubtitleItem = new DevExpress.XtraBars.BarButtonItem();
            this.saveAsItem = new DevExpress.XtraBars.BarButtonItem();
            this.fileSplitSaveItem = new DevExpress.XtraBars.BarButtonItem();
            this.saveAsMacUTF8Item = new DevExpress.XtraBars.BarButtonItem();
            this.exportMutiSaveItem = new DevExpress.XtraBars.BarButtonItem();
            this.closeItem = new DevExpress.XtraBars.BarButtonItem();
            this.quitItem = new DevExpress.XtraBars.BarButtonItem();
            this.editMenu = new DevExpress.XtraBars.BarSubItem();
            this.revocationItem = new DevExpress.XtraBars.BarButtonItem();
            this.redoItem = new DevExpress.XtraBars.BarButtonItem();
            this.cutItem = new DevExpress.XtraBars.BarButtonItem();
            this.copyItem = new DevExpress.XtraBars.BarButtonItem();
            this.pasteItem = new DevExpress.XtraBars.BarButtonItem();
            this.selectItem = new DevExpress.XtraBars.BarButtonItem();
            this.findItem = new DevExpress.XtraBars.BarButtonItem();
            this.findNextItem = new DevExpress.XtraBars.BarButtonItem();
            this.replaceItem = new DevExpress.XtraBars.BarButtonItem();
            this.sortItem = new DevExpress.XtraBars.BarSubItem();
            this.sortByStartTimeItem = new DevExpress.XtraBars.BarButtonItem();
            this.sortByEndTimeItem = new DevExpress.XtraBars.BarButtonItem();
            this.sortByContentItem = new DevExpress.XtraBars.BarButtonItem();
            this.sortByLengthItem = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem4 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem25 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem26 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem27 = new DevExpress.XtraBars.BarButtonItem();
            this.subtitleMenu = new DevExpress.XtraBars.BarSubItem();
            this.addOneLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.addMutiLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.customSplitItem = new DevExpress.XtraBars.BarButtonItem();
            this.combineLineItem = new DevExpress.XtraBars.BarSubItem();
            this.combineOneLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.combineMutiLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.subtitleCombineItem = new DevExpress.XtraBars.BarButtonItem();
            this.deleteItem = new DevExpress.XtraBars.BarButtonItem();
            this.delete2Item = new DevExpress.XtraBars.BarButtonItem();
            this.clearTimeItem = new DevExpress.XtraBars.BarButtonItem();
            this.clearContentItem = new DevExpress.XtraBars.BarButtonItem();
            this.translationTimeItem = new DevExpress.XtraBars.BarButtonItem();
            this.alignNowTimeItem = new DevExpress.XtraBars.BarSubItem();
            this.autoModeItem = new DevExpress.XtraBars.BarCheckItem();
            this.nextItem = new DevExpress.XtraBars.BarButtonItem();
            this.nowLineStartItem = new DevExpress.XtraBars.BarButtonItem();
            this.nowLineEndItem = new DevExpress.XtraBars.BarButtonItem();
            this.onlyNowLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.afterNowLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.allLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.lastSignItem = new DevExpress.XtraBars.BarButtonItem();
            this.alignLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.to23FPSItem = new DevExpress.XtraBars.BarButtonItem();
            this.to25FPSItem = new DevExpress.XtraBars.BarButtonItem();
            this.extendShowItem = new DevExpress.XtraBars.BarButtonItem();
            this.changeUpandDownItem = new DevExpress.XtraBars.BarButtonItem();
            this.lastLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.nextLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.toolMenu = new DevExpress.XtraBars.BarSubItem();
            this.ccSubtitleHandleItem = new DevExpress.XtraBars.BarButtonItem();
            this.ccRemoveDuplicateItem = new DevExpress.XtraBars.BarButtonItem();
            this.ccRemoveDuplicateItemL = new DevExpress.XtraBars.BarButtonItem();
            this.merageAccurateLineItem = new DevExpress.XtraBars.BarButtonItem();
            this.twoLanMerageItem = new DevExpress.XtraBars.BarButtonItem();
            this.addEditorItem = new DevExpress.XtraBars.BarButtonItem();
            this.compareSubtitleItem = new DevExpress.XtraBars.BarButtonItem();
            this.findErrorItem = new DevExpress.XtraBars.BarButtonItem();
            this.createEngNameItem = new DevExpress.XtraBars.BarButtonItem();
            this.replaceEngNameItem = new DevExpress.XtraBars.BarButtonItem();
            this.videoMenu = new DevExpress.XtraBars.BarSubItem();
            this.openVideoItem = new DevExpress.XtraBars.BarButtonItem();
            this.pauseVideoItem = new DevExpress.XtraBars.BarButtonItem();
            this.stopVideoItem = new DevExpress.XtraBars.BarButtonItem();
            this.forwardOneSecItem = new DevExpress.XtraBars.BarButtonItem();
            this.backOneSecItem = new DevExpress.XtraBars.BarButtonItem();
            this.forward5SecItem = new DevExpress.XtraBars.BarButtonItem();
            this.back5SecItem = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItemOneFrame = new DevExpress.XtraBars.BarButtonItem();
            this.subSyncItem = new DevExpress.XtraBars.BarCheckItem();
            this.optionMenu = new DevExpress.XtraBars.BarSubItem();
            this.softwareOptionItem = new DevExpress.XtraBars.BarButtonItem();
            this.viewOptionItem = new DevExpress.XtraBars.BarButtonItem();
            this.hideEffectsItem = new DevExpress.XtraBars.BarCheckItem();
            this.saveAutoItem = new DevExpress.XtraBars.BarCheckItem();
            this.publishMenu = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem74 = new DevExpress.XtraBars.BarButtonItem();
            this.viewMenu = new DevExpress.XtraBars.BarSubItem();
            this.toolsSelectedItem = new DevExpress.XtraBars.BarSubItem();
            this.barCheckItem4 = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem5 = new DevExpress.XtraBars.BarCheckItem();
            this.barCheckItem6 = new DevExpress.XtraBars.BarCheckItem();
            this.barButtonItem75 = new DevExpress.XtraBars.BarButtonItem();
            this.statusItem = new DevExpress.XtraBars.BarCheckItem();
            this.barSubItem15 = new DevExpress.XtraBars.BarSubItem();
            this.helpMenu = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem76 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem77 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem78 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem79 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem80 = new DevExpress.XtraBars.BarButtonItem();
            this.bar3 = new DevExpress.XtraBars.Bar();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.textTimeLinePanel = new DevExpress.XtraEditors.GroupControl();
            this.listView1 = new TimeMDev.YYListView();
            this.listViewMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addOneLineContext = new System.Windows.Forms.ToolStripMenuItem();
            this.addMutiLineContext = new System.Windows.Forms.ToolStripMenuItem();
            this.moveTimeContext = new System.Windows.Forms.ToolStripMenuItem();
            this.alignNowLineContext = new System.Windows.Forms.ToolStripMenuItem();
            this.alignAfterLineContext = new System.Windows.Forms.ToolStripMenuItem();
            this.alignAllLineContext = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.customSpiltContext = new System.Windows.Forms.ToolStripMenuItem();
            this.combineOneLineContext = new System.Windows.Forms.ToolStripMenuItem();
            this.combineMutiLineContext = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.deleteLineContext = new System.Windows.Forms.ToolStripMenuItem();
            this.zeroTime = new System.Windows.Forms.ToolStripMenuItem();
            this.zeroContentContext = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.undoContext = new System.Windows.Forms.ToolStripMenuItem();
            this.repeatContext = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.cutContext = new System.Windows.Forms.ToolStripMenuItem();
            this.copyContext = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteContext = new System.Windows.Forms.ToolStripMenuItem();
            this.checkAllContext = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).BeginInit();
            this.dockPanel1.SuspendLayout();
            this.dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).BeginInit();
            this.panelContainer1.SuspendLayout();
            this.videoPanel.SuspendLayout();
            this.dockPanel3_Container.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.movieTrack)).BeginInit();
            this.panel2.SuspendLayout();
            this.toolStripPanel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.modifySubtitlePanel.SuspendLayout();
            this.dockPanel4_Container.SuspendLayout();
            this.panel3.SuspendLayout();
            this.picTimeLinePanel.SuspendLayout();
            this.dockPanel2_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rateShow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textTimeLinePanel)).BeginInit();
            this.textTimeLinePanel.SuspendLayout();
            this.listViewMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // dockManager1
            // 
            this.dockManager1.Form = this;
            this.dockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.dockPanel1,
            this.panelContainer1,
            this.picTimeLinePanel});
            this.dockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl"});
            // 
            // dockPanel1
            // 
            this.dockPanel1.Controls.Add(this.dockPanel1_Container);
            this.dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.dockPanel1.ID = new System.Guid("969a68cf-36f5-41da-89e3-0897c6ea1f28");
            this.dockPanel1.Location = new System.Drawing.Point(0, 24);
            this.dockPanel1.Name = "dockPanel1";
            this.dockPanel1.OriginalSize = new System.Drawing.Size(131, 200);
            this.dockPanel1.Size = new System.Drawing.Size(131, 551);
            this.dockPanel1.Text = "功能栏";
            // 
            // dockPanel1_Container
            // 
            this.dockPanel1_Container.Controls.Add(this.navBarControl1);
            this.dockPanel1_Container.Location = new System.Drawing.Point(4, 23);
            this.dockPanel1_Container.Name = "dockPanel1_Container";
            this.dockPanel1_Container.Size = new System.Drawing.Size(123, 524);
            this.dockPanel1_Container.TabIndex = 0;
            // 
            // navBarControl1
            // 
            this.navBarControl1.ActiveGroup = this.navBarGroup1;
            this.navBarControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navBarControl1.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.navBarGroup1,
            this.navBarGroup2,
            this.navBarGroup3,
            this.navBarGroup4});
            this.navBarControl1.Items.AddRange(new DevExpress.XtraNavBar.NavBarItem[] {
            this.openSubtitleLink,
            this.openVideoLink,
            this.newSubtitleLink,
            this.loadTxtLink,
            this.addSubtitleLink,
            this.ccHandleLink,
            this.exportSubtitleItem,
            this.saveSubtitleLink,
            this.merageToEndLink,
            this.merageToNewLink,
            this.cutLineLink,
            this.alignNowLineLink,
            this.alignNextLineLink,
            this.alignAllLineLink,
            this.alignToBeforeSignLink,
            this.alignToAfterSignLink,
            this.translationTimeLink,
            this.mergeTwoLanLink,
            this.findErrorLink,
            this.startMplayerFristTimeLink});
            this.navBarControl1.Location = new System.Drawing.Point(0, 0);
            this.navBarControl1.Name = "navBarControl1";
            this.navBarControl1.OptionsNavPane.ExpandedWidth = 192;
            this.navBarControl1.Size = new System.Drawing.Size(123, 524);
            this.navBarControl1.TabIndex = 0;
            this.navBarControl1.Text = "navBarControl1";
            // 
            // navBarGroup1
            // 
            this.navBarGroup1.Caption = "打开字幕";
            this.navBarGroup1.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.openSubtitleLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.openVideoLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.newSubtitleLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.loadTxtLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.addSubtitleLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.ccHandleLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.exportSubtitleItem),
            new DevExpress.XtraNavBar.NavBarItemLink(this.saveSubtitleLink)});
            this.navBarGroup1.Name = "navBarGroup1";
            // 
            // openSubtitleLink
            // 
            this.openSubtitleLink.Caption = "打开字幕";
            this.openSubtitleLink.LargeImage = ((System.Drawing.Image)(resources.GetObject("openSubtitleLink.LargeImage")));
            this.openSubtitleLink.Name = "openSubtitleLink";
            this.openSubtitleLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("openSubtitleLink.SmallImage")));
            this.openSubtitleLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.openSubtitleLink_LinkClicked);
            // 
            // openVideoLink
            // 
            this.openVideoLink.Caption = "打开视频";
            this.openVideoLink.Name = "openVideoLink";
            this.openVideoLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("openVideoLink.SmallImage")));
            this.openVideoLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.openVideoLink_LinkClicked);
            // 
            // newSubtitleLink
            // 
            this.newSubtitleLink.Caption = "新字幕";
            this.newSubtitleLink.Name = "newSubtitleLink";
            this.newSubtitleLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("newSubtitleLink.SmallImage")));
            this.newSubtitleLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.newSubtitleLink_LinkClicked);
            // 
            // loadTxtLink
            // 
            this.loadTxtLink.Caption = "导入文本";
            this.loadTxtLink.Name = "loadTxtLink";
            this.loadTxtLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("loadTxtLink.SmallImage")));
            this.loadTxtLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.loadTxtLink_LinkClicked);
            // 
            // addSubtitleLink
            // 
            this.addSubtitleLink.Caption = "追加字幕";
            this.addSubtitleLink.Name = "addSubtitleLink";
            this.addSubtitleLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("addSubtitleLink.SmallImage")));
            this.addSubtitleLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.addSubtitleLink_LinkClicked);
            // 
            // ccHandleLink
            // 
            this.ccHandleLink.Caption = "CC处理";
            this.ccHandleLink.Name = "ccHandleLink";
            this.ccHandleLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("ccHandleLink.SmallImage")));
            this.ccHandleLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ccHandleLink_LinkClicked);
            // 
            // exportSubtitleItem
            // 
            this.exportSubtitleItem.Caption = "输出字幕";
            this.exportSubtitleItem.Name = "exportSubtitleItem";
            this.exportSubtitleItem.SmallImage = ((System.Drawing.Image)(resources.GetObject("exportSubtitleItem.SmallImage")));
            this.exportSubtitleItem.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.exportSubtitleItem_LinkClicked);
            // 
            // saveSubtitleLink
            // 
            this.saveSubtitleLink.Caption = "保存字幕";
            this.saveSubtitleLink.Name = "saveSubtitleLink";
            this.saveSubtitleLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("saveSubtitleLink.SmallImage")));
            this.saveSubtitleLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.saveSubtitleLink_LinkClicked);
            // 
            // navBarGroup2
            // 
            this.navBarGroup2.Caption = "字幕编辑";
            this.navBarGroup2.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.merageToEndLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.merageToNewLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.cutLineLink)});
            this.navBarGroup2.Name = "navBarGroup2";
            // 
            // merageToEndLink
            // 
            this.merageToEndLink.Caption = "合并至单行尾部";
            this.merageToEndLink.Name = "merageToEndLink";
            this.merageToEndLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("merageToEndLink.SmallImage")));
            this.merageToEndLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.merageToEndLink_LinkClicked);
            // 
            // merageToNewLink
            // 
            this.merageToNewLink.Caption = "合并至新行";
            this.merageToNewLink.Name = "merageToNewLink";
            this.merageToNewLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("merageToNewLink.SmallImage")));
            this.merageToNewLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.merageToNewLink_LinkClicked);
            // 
            // cutLineLink
            // 
            this.cutLineLink.Caption = "拆分字幕";
            this.cutLineLink.Name = "cutLineLink";
            this.cutLineLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("cutLineLink.SmallImage")));
            this.cutLineLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.cutLineLink_LinkClicked);
            // 
            // navBarGroup3
            // 
            this.navBarGroup3.Caption = "时间轴编辑";
            this.navBarGroup3.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.alignNowLineLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.alignNextLineLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.alignAllLineLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.alignToBeforeSignLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.alignToAfterSignLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.translationTimeLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.mergeTwoLanLink),
            new DevExpress.XtraNavBar.NavBarItemLink(this.findErrorLink)});
            this.navBarGroup3.Name = "navBarGroup3";
            // 
            // alignNowLineLink
            // 
            this.alignNowLineLink.Caption = "对齐当前行";
            this.alignNowLineLink.Name = "alignNowLineLink";
            this.alignNowLineLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("alignNowLineLink.SmallImage")));
            this.alignNowLineLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.alignNowLineLink_LinkClicked);
            // 
            // alignNextLineLink
            // 
            this.alignNextLineLink.Caption = "对齐后续行";
            this.alignNextLineLink.Name = "alignNextLineLink";
            this.alignNextLineLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("alignNextLineLink.SmallImage")));
            this.alignNextLineLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.alignNextLineLink_LinkClicked);
            // 
            // alignAllLineLink
            // 
            this.alignAllLineLink.Caption = "对齐全部行";
            this.alignAllLineLink.Name = "alignAllLineLink";
            this.alignAllLineLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("alignAllLineLink.SmallImage")));
            this.alignAllLineLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.alignAllLineLink_LinkClicked);
            // 
            // alignToBeforeSignLink
            // 
            this.alignToBeforeSignLink.Caption = "对齐至前标记";
            this.alignToBeforeSignLink.Name = "alignToBeforeSignLink";
            this.alignToBeforeSignLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("alignToBeforeSignLink.SmallImage")));
            this.alignToBeforeSignLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.alignToBeforeSignLink_LinkClicked);
            // 
            // alignToAfterSignLink
            // 
            this.alignToAfterSignLink.Caption = "对齐至后标记";
            this.alignToAfterSignLink.Name = "alignToAfterSignLink";
            this.alignToAfterSignLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("alignToAfterSignLink.SmallImage")));
            this.alignToAfterSignLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.alignToAfterSignLink_LinkClicked);
            // 
            // translationTimeLink
            // 
            this.translationTimeLink.Caption = "平移时间";
            this.translationTimeLink.Name = "translationTimeLink";
            this.translationTimeLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("translationTimeLink.SmallImage")));
            this.translationTimeLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.translationTimeLink_LinkClicked);
            // 
            // mergeTwoLanLink
            // 
            this.mergeTwoLanLink.Caption = "双语合并";
            this.mergeTwoLanLink.Name = "mergeTwoLanLink";
            this.mergeTwoLanLink.Visible = false;
            this.mergeTwoLanLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.mergeTwoLanLink_LinkClicked);
            // 
            // findErrorLink
            // 
            this.findErrorLink.Caption = "检查除错";
            this.findErrorLink.Name = "findErrorLink";
            this.findErrorLink.SmallImage = ((System.Drawing.Image)(resources.GetObject("findErrorLink.SmallImage")));
            this.findErrorLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.findErrorLink_LinkClicked);
            // 
            // navBarGroup4
            // 
            this.navBarGroup4.Caption = "MPlayer选项";
            this.navBarGroup4.Expanded = true;
            this.navBarGroup4.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.startMplayerFristTimeLink)});
            this.navBarGroup4.Name = "navBarGroup4";
            // 
            // startMplayerFristTimeLink
            // 
            this.startMplayerFristTimeLink.Caption = "首次打开软件";
            this.startMplayerFristTimeLink.Name = "startMplayerFristTimeLink";
            this.startMplayerFristTimeLink.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.startMplayerFristTimeLink_LinkClicked);
            // 
            // panelContainer1
            // 
            this.panelContainer1.Controls.Add(this.videoPanel);
            this.panelContainer1.Controls.Add(this.modifySubtitlePanel);
            this.panelContainer1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Top;
            this.panelContainer1.FloatVertical = true;
            this.panelContainer1.ID = new System.Guid("69606b57-fcf3-4d4d-a7a3-7e75373d77e5");
            this.panelContainer1.Location = new System.Drawing.Point(131, 24);
            this.panelContainer1.Name = "panelContainer1";
            this.panelContainer1.OriginalSize = new System.Drawing.Size(200, 252);
            this.panelContainer1.Size = new System.Drawing.Size(1055, 252);
            this.panelContainer1.Text = "panelContainer1";
            // 
            // videoPanel
            // 
            this.videoPanel.Controls.Add(this.dockPanel3_Container);
            this.videoPanel.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.videoPanel.ID = new System.Guid("b4edf9e8-4959-4e1d-8ef7-e802000544ee");
            this.videoPanel.Location = new System.Drawing.Point(0, 0);
            this.videoPanel.Name = "videoPanel";
            this.videoPanel.OriginalSize = new System.Drawing.Size(493, 252);
            this.videoPanel.Size = new System.Drawing.Size(519, 252);
            this.videoPanel.Text = " 视频播放";
            // 
            // dockPanel3_Container
            // 
            this.dockPanel3_Container.Controls.Add(this.videoPlayPanel);
            this.dockPanel3_Container.Controls.Add(this.panel1);
            this.dockPanel3_Container.Controls.Add(this.panel2);
            this.dockPanel3_Container.Location = new System.Drawing.Point(4, 23);
            this.dockPanel3_Container.Name = "dockPanel3_Container";
            this.dockPanel3_Container.Size = new System.Drawing.Size(511, 225);
            this.dockPanel3_Container.TabIndex = 0;
            // 
            // videoPlayPanel
            // 
            this.videoPlayPanel.BackColor = System.Drawing.Color.Black;
            this.videoPlayPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.videoPlayPanel.Location = new System.Drawing.Point(0, 0);
            this.videoPlayPanel.Name = "videoPlayPanel";
            this.videoPlayPanel.Size = new System.Drawing.Size(511, 168);
            this.videoPlayPanel.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.nowTimeLineShow);
            this.panel1.Controls.Add(this.movieTrack);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 168);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(511, 25);
            this.panel1.TabIndex = 0;
            // 
            // nowTimeLineShow
            // 
            this.nowTimeLineShow.BackColor = System.Drawing.Color.Black;
            this.nowTimeLineShow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nowTimeLineShow.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nowTimeLineShow.ForeColor = System.Drawing.Color.Yellow;
            this.nowTimeLineShow.Location = new System.Drawing.Point(0, 0);
            this.nowTimeLineShow.Name = "nowTimeLineShow";
            this.nowTimeLineShow.Size = new System.Drawing.Size(511, 1);
            this.nowTimeLineShow.TabIndex = 7;
            this.nowTimeLineShow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // movieTrack
            // 
            this.movieTrack.AutoSize = false;
            this.movieTrack.BackColor = System.Drawing.Color.Black;
            this.movieTrack.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.movieTrack.Location = new System.Drawing.Point(0, 1);
            this.movieTrack.Name = "movieTrack";
            this.movieTrack.Size = new System.Drawing.Size(511, 24);
            this.movieTrack.TabIndex = 0;
            this.movieTrack.TickStyle = System.Windows.Forms.TickStyle.None;
            this.movieTrack.MouseDown += new System.Windows.Forms.MouseEventHandler(this.movieTrack_MouseDown);
            this.movieTrack.MouseUp += new System.Windows.Forms.MouseEventHandler(this.movieTrack_MouseUp);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.toolStripPanel1);
            this.panel2.Controls.Add(this.toolStrip2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 193);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(511, 32);
            this.panel2.TabIndex = 0;
            // 
            // toolStripPanel1
            // 
            this.toolStripPanel1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripPanel1.Controls.Add(this.toolStrip1);
            this.toolStripPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStripPanel1.Location = new System.Drawing.Point(0, 0);
            this.toolStripPanel1.Name = "toolStripPanel1";
            this.toolStripPanel1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.toolStripPanel1.RowMargin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.toolStripPanel1.Size = new System.Drawing.Size(232, 32);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLoadFile,
            this.toolStripSeparator5,
            this.toolStripPlay,
            this.toolStripPause,
            this.toolStripSeparator6,
            this.toolStripBack5,
            this.toolStripForward5,
            this.toolStripBack10,
            this.toolStripForward10,
            this.toolStripSeparator7,
            this.toolStrip1Step,
            this.toolStripSyn,
            this.toolStripSeparator8});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 3);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(232, 23);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLoadFile
            // 
            this.toolStripLoadFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripLoadFile.Image = ((System.Drawing.Image)(resources.GetObject("toolStripLoadFile.Image")));
            this.toolStripLoadFile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripLoadFile.Name = "toolStripLoadFile";
            this.toolStripLoadFile.Size = new System.Drawing.Size(23, 20);
            this.toolStripLoadFile.Text = "toolStripButton1";
            this.toolStripLoadFile.ToolTipText = "打开";
            this.toolStripLoadFile.Click += new System.EventHandler(this.toolStripLoadFile_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStripPlay
            // 
            this.toolStripPlay.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripPlay.Image = ((System.Drawing.Image)(resources.GetObject("toolStripPlay.Image")));
            this.toolStripPlay.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripPlay.Name = "toolStripPlay";
            this.toolStripPlay.Size = new System.Drawing.Size(23, 20);
            this.toolStripPlay.Text = "toolStripButton2";
            this.toolStripPlay.ToolTipText = "播放";
            this.toolStripPlay.Click += new System.EventHandler(this.toolStripPlay_Click);
            // 
            // toolStripPause
            // 
            this.toolStripPause.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripPause.Image = ((System.Drawing.Image)(resources.GetObject("toolStripPause.Image")));
            this.toolStripPause.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripPause.Name = "toolStripPause";
            this.toolStripPause.Size = new System.Drawing.Size(23, 20);
            this.toolStripPause.Text = "toolStripButton3";
            this.toolStripPause.ToolTipText = "暂停";
            this.toolStripPause.Click += new System.EventHandler(this.toolStripPause_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStripBack5
            // 
            this.toolStripBack5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripBack5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripBack5.Image")));
            this.toolStripBack5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripBack5.Name = "toolStripBack5";
            this.toolStripBack5.Size = new System.Drawing.Size(23, 20);
            this.toolStripBack5.Text = "toolStripButton4";
            this.toolStripBack5.ToolTipText = "快退1S";
            this.toolStripBack5.Click += new System.EventHandler(this.toolStripBack5_Click);
            // 
            // toolStripForward5
            // 
            this.toolStripForward5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripForward5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripForward5.Image")));
            this.toolStripForward5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripForward5.Name = "toolStripForward5";
            this.toolStripForward5.Size = new System.Drawing.Size(23, 20);
            this.toolStripForward5.Text = "快进5S";
            this.toolStripForward5.ToolTipText = "快进1S";
            this.toolStripForward5.Click += new System.EventHandler(this.toolStripForward5_Click);
            // 
            // toolStripBack10
            // 
            this.toolStripBack10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripBack10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripBack10.Image")));
            this.toolStripBack10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripBack10.Name = "toolStripBack10";
            this.toolStripBack10.Size = new System.Drawing.Size(23, 20);
            this.toolStripBack10.Text = "快退10S";
            this.toolStripBack10.ToolTipText = "快退5S";
            this.toolStripBack10.Click += new System.EventHandler(this.toolStripBack10_Click);
            // 
            // toolStripForward10
            // 
            this.toolStripForward10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripForward10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripForward10.Image")));
            this.toolStripForward10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripForward10.Name = "toolStripForward10";
            this.toolStripForward10.Size = new System.Drawing.Size(23, 20);
            this.toolStripForward10.Text = "快进10S";
            this.toolStripForward10.ToolTipText = "快进5S";
            this.toolStripForward10.Click += new System.EventHandler(this.toolStripForward10_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStrip1Step
            // 
            this.toolStrip1Step.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStrip1Step.Image = ((System.Drawing.Image)(resources.GetObject("toolStrip1Step.Image")));
            this.toolStrip1Step.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStrip1Step.Name = "toolStrip1Step";
            this.toolStrip1Step.Size = new System.Drawing.Size(23, 20);
            this.toolStrip1Step.Text = "下一帧";
            this.toolStrip1Step.Click += new System.EventHandler(this.toolStrip1Step_Click);
            // 
            // toolStripSyn
            // 
            this.toolStripSyn.CheckOnClick = true;
            this.toolStripSyn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSyn.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSyn.Image")));
            this.toolStripSyn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSyn.Name = "toolStripSyn";
            this.toolStripSyn.Size = new System.Drawing.Size(23, 20);
            this.toolStripSyn.Text = "同步";
            this.toolStripSyn.Click += new System.EventHandler(this.toolStripSyn_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripAlignNow,
            this.toolStripAlignAfter,
            this.toolStripAlighAll,
            this.toolStripSeparator9,
            this.toolStripAlighStart,
            this.toolStripAlighEnd,
            this.toolStripSeparator10,
            this.toolStripAddOne,
            this.toolStripAddMuti,
            this.toolStripSeparator11,
            this.toolStripSaveAuto,
            this.toolStripSign,
            this.toolStripSync});
            this.toolStrip2.Location = new System.Drawing.Point(237, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(260, 25);
            this.toolStrip2.TabIndex = 1;
            // 
            // toolStripAlignNow
            // 
            this.toolStripAlignNow.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlignNow.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlignNow.Image")));
            this.toolStripAlignNow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlignNow.Name = "toolStripAlignNow";
            this.toolStripAlignNow.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlignNow.Text = "将播放器的时间同步到此时间轴";
            this.toolStripAlignNow.Click += new System.EventHandler(this.toolStripAlignNow_Click);
            // 
            // toolStripAlignAfter
            // 
            this.toolStripAlignAfter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlignAfter.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlignAfter.Image")));
            this.toolStripAlignAfter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlignAfter.Name = "toolStripAlignAfter";
            this.toolStripAlignAfter.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlignAfter.Text = "以当前的播放器时间对其以后的时间";
            this.toolStripAlignAfter.Click += new System.EventHandler(this.toolStripAlignAfter_Click);
            // 
            // toolStripAlighAll
            // 
            this.toolStripAlighAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlighAll.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlighAll.Image")));
            this.toolStripAlighAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlighAll.Name = "toolStripAlighAll";
            this.toolStripAlighAll.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlighAll.Text = "以现在播放器时间对其所有时间";
            this.toolStripAlighAll.Click += new System.EventHandler(this.toolStripAlighAll_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripAlighStart
            // 
            this.toolStripAlighStart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlighStart.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlighStart.Image")));
            this.toolStripAlighStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlighStart.Name = "toolStripAlighStart";
            this.toolStripAlighStart.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlighStart.Text = "对其开始时间";
            this.toolStripAlighStart.Click += new System.EventHandler(this.toolStripAlighStart_Click);
            // 
            // toolStripAlighEnd
            // 
            this.toolStripAlighEnd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAlighEnd.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAlighEnd.Image")));
            this.toolStripAlighEnd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAlighEnd.Name = "toolStripAlighEnd";
            this.toolStripAlighEnd.Size = new System.Drawing.Size(23, 22);
            this.toolStripAlighEnd.Text = "对其结束时间";
            this.toolStripAlighEnd.Click += new System.EventHandler(this.toolStripAlighEnd_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripAddOne
            // 
            this.toolStripAddOne.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAddOne.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAddOne.Image")));
            this.toolStripAddOne.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAddOne.Name = "toolStripAddOne";
            this.toolStripAddOne.Size = new System.Drawing.Size(23, 22);
            this.toolStripAddOne.Text = "增加一行";
            this.toolStripAddOne.Click += new System.EventHandler(this.toolStripAddOne_Click);
            // 
            // toolStripAddMuti
            // 
            this.toolStripAddMuti.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAddMuti.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAddMuti.Image")));
            this.toolStripAddMuti.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAddMuti.Name = "toolStripAddMuti";
            this.toolStripAddMuti.Size = new System.Drawing.Size(23, 22);
            this.toolStripAddMuti.Text = "增加多行";
            this.toolStripAddMuti.Click += new System.EventHandler(this.toolStripAddMuti_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSaveAuto
            // 
            this.toolStripSaveAuto.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSaveAuto.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSaveAuto.Image")));
            this.toolStripSaveAuto.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSaveAuto.Name = "toolStripSaveAuto";
            this.toolStripSaveAuto.Size = new System.Drawing.Size(23, 22);
            this.toolStripSaveAuto.Text = "自动保存";
            this.toolStripSaveAuto.Click += new System.EventHandler(this.toolStripSaveAuto_Click);
            // 
            // toolStripSign
            // 
            this.toolStripSign.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSign.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSign.Image")));
            this.toolStripSign.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSign.Name = "toolStripSign";
            this.toolStripSign.Size = new System.Drawing.Size(23, 22);
            this.toolStripSign.Text = "标记当前行";
            this.toolStripSign.Click += new System.EventHandler(this.toolStripSign_Click);
            // 
            // toolStripSync
            // 
            this.toolStripSync.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSync.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSync.Name = "toolStripSync";
            this.toolStripSync.Size = new System.Drawing.Size(23, 22);
            this.toolStripSync.Text = "toolStripButton1";
            this.toolStripSync.Click += new System.EventHandler(this.toolStripSync_Click);
            // 
            // modifySubtitlePanel
            // 
            this.modifySubtitlePanel.Controls.Add(this.dockPanel4_Container);
            this.modifySubtitlePanel.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.modifySubtitlePanel.FloatVertical = true;
            this.modifySubtitlePanel.ID = new System.Guid("d5f1cb44-9ef1-4a4b-bac9-7abcb6e9fee2");
            this.modifySubtitlePanel.Location = new System.Drawing.Point(519, 0);
            this.modifySubtitlePanel.Name = "modifySubtitlePanel";
            this.modifySubtitlePanel.OriginalSize = new System.Drawing.Size(562, 252);
            this.modifySubtitlePanel.Size = new System.Drawing.Size(536, 252);
            this.modifySubtitlePanel.Text = "修改字幕";
            // 
            // dockPanel4_Container
            // 
            this.dockPanel4_Container.Controls.Add(this.contentEdit);
            this.dockPanel4_Container.Controls.Add(this.panel3);
            this.dockPanel4_Container.Location = new System.Drawing.Point(4, 23);
            this.dockPanel4_Container.Name = "dockPanel4_Container";
            this.dockPanel4_Container.Size = new System.Drawing.Size(528, 225);
            this.dockPanel4_Container.TabIndex = 0;
            // 
            // contentEdit
            // 
            this.contentEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentEdit.Location = new System.Drawing.Point(123, 0);
            this.contentEdit.Multiline = true;
            this.contentEdit.Name = "contentEdit";
            this.contentEdit.Size = new System.Drawing.Size(405, 225);
            this.contentEdit.TabIndex = 16;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.confirmChange);
            this.panel3.Controls.Add(this.timeEditStart);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.timeEditEnd);
            this.panel3.Controls.Add(this.numEdit);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(123, 225);
            this.panel3.TabIndex = 19;
            // 
            // confirmChange
            // 
            this.confirmChange.Location = new System.Drawing.Point(2, 142);
            this.confirmChange.Name = "confirmChange";
            this.confirmChange.Size = new System.Drawing.Size(79, 23);
            this.confirmChange.TabIndex = 17;
            this.confirmChange.Text = "修改";
            this.confirmChange.UseVisualStyleBackColor = true;
            this.confirmChange.Click += new System.EventHandler(this.confirmChange_Click);
            // 
            // timeEditStart
            // 
            this.timeEditStart.Location = new System.Drawing.Point(3, 22);
            this.timeEditStart.Name = "timeEditStart";
            this.timeEditStart.Size = new System.Drawing.Size(115, 21);
            this.timeEditStart.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 18;
            this.label3.Text = "序号：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 18;
            this.label1.Text = "开始时间：";
            // 
            // timeEditEnd
            // 
            this.timeEditEnd.Location = new System.Drawing.Point(1, 61);
            this.timeEditEnd.Name = "timeEditEnd";
            this.timeEditEnd.Size = new System.Drawing.Size(114, 21);
            this.timeEditEnd.TabIndex = 15;
            // 
            // numEdit
            // 
            this.numEdit.Location = new System.Drawing.Point(2, 109);
            this.numEdit.Name = "numEdit";
            this.numEdit.Size = new System.Drawing.Size(78, 21);
            this.numEdit.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 18;
            this.label2.Text = "停止时间：";
            // 
            // picTimeLinePanel
            // 
            this.picTimeLinePanel.Controls.Add(this.dockPanel2_Container);
            this.picTimeLinePanel.Dock = DevExpress.XtraBars.Docking.DockingStyle.Top;
            this.picTimeLinePanel.FloatVertical = true;
            this.picTimeLinePanel.ID = new System.Guid("ee3c6f74-b203-46a9-b484-9a8d7ae5e6d0");
            this.picTimeLinePanel.Location = new System.Drawing.Point(131, 276);
            this.picTimeLinePanel.Name = "picTimeLinePanel";
            this.picTimeLinePanel.OriginalSize = new System.Drawing.Size(200, 163);
            this.picTimeLinePanel.Size = new System.Drawing.Size(1055, 163);
            this.picTimeLinePanel.Text = "可视化时间轴";
            // 
            // dockPanel2_Container
            // 
            this.dockPanel2_Container.Controls.Add(this.rateShow);
            this.dockPanel2_Container.Controls.Add(this.nowTimeShow);
            this.dockPanel2_Container.Location = new System.Drawing.Point(4, 23);
            this.dockPanel2_Container.Name = "dockPanel2_Container";
            this.dockPanel2_Container.Size = new System.Drawing.Size(1047, 136);
            this.dockPanel2_Container.TabIndex = 0;
            // 
            // rateShow
            // 
            this.rateShow.BackColor = System.Drawing.Color.Black;
            this.rateShow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rateShow.Location = new System.Drawing.Point(0, 0);
            this.rateShow.Name = "rateShow";
            this.rateShow.Size = new System.Drawing.Size(1047, 101);
            this.rateShow.TabIndex = 0;
            this.rateShow.TabStop = false;
            this.rateShow.MouseMove += new System.Windows.Forms.MouseEventHandler(this.rateShow_MouseMove);
            this.rateShow.Click += new System.EventHandler(this.rateShow_Click);
            this.rateShow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.rateShow_MouseDown);
            this.rateShow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.rateShow_MouseUp);
            // 
            // nowTimeShow
            // 
            this.nowTimeShow.BackColor = System.Drawing.Color.Black;
            this.nowTimeShow.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.nowTimeShow.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nowTimeShow.ForeColor = System.Drawing.Color.Yellow;
            this.nowTimeShow.Location = new System.Drawing.Point(0, 101);
            this.nowTimeShow.Name = "nowTimeShow";
            this.nowTimeShow.Size = new System.Drawing.Size(1047, 35);
            this.nowTimeShow.TabIndex = 8;
            this.nowTimeShow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar2,
            this.bar3});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.DockManager = this.dockManager1;
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.fileMenu,
            this.newSubtitleItem,
            this.loadSubtitleItem,
            this.loadTranslationItem,
            this.addSubtitleItem,
            this.saveSubtitleItem,
            this.saveAsItem,
            this.fileSplitSaveItem,
            this.saveAsMacUTF8Item,
            this.exportMutiSaveItem,
            this.closeItem,
            this.quitItem,
            this.editMenu,
            this.revocationItem,
            this.redoItem,
            this.cutItem,
            this.copyItem,
            this.pasteItem,
            this.selectItem,
            this.findItem,
            this.findNextItem,
            this.replaceItem,
            this.sortItem,
            this.sortByStartTimeItem,
            this.sortByEndTimeItem,
            this.sortByContentItem,
            this.sortByLengthItem,
            this.barSubItem4,
            this.barButtonItem25,
            this.barButtonItem26,
            this.barButtonItem27,
            this.subtitleMenu,
            this.addOneLineItem,
            this.addMutiLineItem,
            this.customSplitItem,
            this.combineLineItem,
            this.subtitleCombineItem,
            this.deleteItem,
            this.delete2Item,
            this.clearTimeItem,
            this.clearContentItem,
            this.translationTimeItem,
            this.alignNowTimeItem,
            this.to23FPSItem,
            this.to25FPSItem,
            this.extendShowItem,
            this.changeUpandDownItem,
            this.lastLineItem,
            this.nextLineItem,
            this.combineOneLineItem,
            this.combineMutiLineItem,
            this.nextItem,
            this.nowLineStartItem,
            this.nowLineEndItem,
            this.onlyNowLineItem,
            this.afterNowLineItem,
            this.allLineItem,
            this.lastSignItem,
            this.alignLineItem,
            this.toolMenu,
            this.ccSubtitleHandleItem,
            this.ccRemoveDuplicateItem,
            this.merageAccurateLineItem,
            this.twoLanMerageItem,
            this.addEditorItem,
            this.compareSubtitleItem,
            this.findErrorItem,
            this.createEngNameItem,
            this.replaceEngNameItem,
            this.videoMenu,
            this.openVideoItem,
            this.pauseVideoItem,
            this.stopVideoItem,
            this.forwardOneSecItem,
            this.backOneSecItem,
            this.forward5SecItem,
            this.back5SecItem,
            this.barButtonItemOneFrame,
            this.optionMenu,
            this.softwareOptionItem,
            this.viewOptionItem,
            this.hideEffectsItem,
            this.saveAutoItem,
            this.publishMenu,
            this.barButtonItem74,
            this.viewMenu,
            this.helpMenu,
            this.toolsSelectedItem,
            this.statusItem,
            this.barCheckItem4,
            this.barCheckItem5,
            this.barCheckItem6,
            this.barButtonItem75,
            this.barSubItem15,
            this.barButtonItem76,
            this.barButtonItem77,
            this.barButtonItem78,
            this.barButtonItem79,
            this.barButtonItem80,
            this.ccRemoveDuplicateItemL,
            this.subSyncItem,
            this.autoModeItem});
            this.barManager1.MainMenu = this.bar2;
            this.barManager1.MaxItemId = 110;
            this.barManager1.StatusBar = this.bar3;
            // 
            // bar2
            // 
            this.bar2.BarName = "Main menu";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.fileMenu),
            new DevExpress.XtraBars.LinkPersistInfo(this.editMenu),
            new DevExpress.XtraBars.LinkPersistInfo(this.subtitleMenu),
            new DevExpress.XtraBars.LinkPersistInfo(this.toolMenu),
            new DevExpress.XtraBars.LinkPersistInfo(this.videoMenu),
            new DevExpress.XtraBars.LinkPersistInfo(this.optionMenu),
            new DevExpress.XtraBars.LinkPersistInfo(this.publishMenu),
            new DevExpress.XtraBars.LinkPersistInfo(this.viewMenu),
            new DevExpress.XtraBars.LinkPersistInfo(this.helpMenu)});
            this.bar2.OptionsBar.MultiLine = true;
            this.bar2.OptionsBar.UseWholeRow = true;
            this.bar2.Text = "Main menu";
            // 
            // fileMenu
            // 
            this.fileMenu.Caption = "文件(F)";
            this.fileMenu.Id = 1;
            this.fileMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.newSubtitleItem, DevExpress.XtraBars.BarItemPaintStyle.Standard),
            new DevExpress.XtraBars.LinkPersistInfo(this.loadSubtitleItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.loadTranslationItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.addSubtitleItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.saveSubtitleItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.saveAsItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.fileSplitSaveItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.saveAsMacUTF8Item),
            new DevExpress.XtraBars.LinkPersistInfo(this.exportMutiSaveItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.closeItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.quitItem, true)});
            this.fileMenu.Name = "fileMenu";
            // 
            // newSubtitleItem
            // 
            this.newSubtitleItem.Caption = "新建字幕";
            this.newSubtitleItem.Id = 2;
            this.newSubtitleItem.Name = "newSubtitleItem";
            this.newSubtitleItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.newSubtitleItem_ItemClick);
            // 
            // loadSubtitleItem
            // 
            this.loadSubtitleItem.Caption = "打开字幕";
            this.loadSubtitleItem.Id = 3;
            this.loadSubtitleItem.Name = "loadSubtitleItem";
            this.loadSubtitleItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.loadSubtitleItem_ItemClick);
            // 
            // loadTranslationItem
            // 
            this.loadTranslationItem.Caption = "导入翻译稿";
            this.loadTranslationItem.Id = 4;
            this.loadTranslationItem.Name = "loadTranslationItem";
            this.loadTranslationItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.loadTranslationItem_ItemClick);
            // 
            // addSubtitleItem
            // 
            this.addSubtitleItem.Caption = "追加字幕";
            this.addSubtitleItem.Id = 5;
            this.addSubtitleItem.Name = "addSubtitleItem";
            this.addSubtitleItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.addSubtitleItem_ItemClick);
            // 
            // saveSubtitleItem
            // 
            this.saveSubtitleItem.Caption = "保存字幕...";
            this.saveSubtitleItem.Id = 6;
            this.saveSubtitleItem.Name = "saveSubtitleItem";
            this.saveSubtitleItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.saveSubtitleItem_ItemClick);
            // 
            // saveAsItem
            // 
            this.saveAsItem.Caption = "另存为...";
            this.saveAsItem.Id = 7;
            this.saveAsItem.Name = "saveAsItem";
            this.saveAsItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.saveAsItem_ItemClick);
            // 
            // fileSplitSaveItem
            // 
            this.fileSplitSaveItem.Caption = "文件分割另存为...";
            this.fileSplitSaveItem.Id = 8;
            this.fileSplitSaveItem.Name = "fileSplitSaveItem";
            this.fileSplitSaveItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.fileSplitSaveItem_ItemClick);
            // 
            // saveAsMacUTF8Item
            // 
            this.saveAsMacUTF8Item.Caption = "导出为Mac-UTF8格式...";
            this.saveAsMacUTF8Item.Id = 9;
            this.saveAsMacUTF8Item.Name = "saveAsMacUTF8Item";
            // 
            // exportMutiSaveItem
            // 
            this.exportMutiSaveItem.Caption = "批量导出多版本...";
            this.exportMutiSaveItem.Id = 10;
            this.exportMutiSaveItem.Name = "exportMutiSaveItem";
            this.exportMutiSaveItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.exportMutiSaveItem_ItemClick);
            // 
            // closeItem
            // 
            this.closeItem.Caption = "关闭";
            this.closeItem.Id = 11;
            this.closeItem.Name = "closeItem";
            // 
            // quitItem
            // 
            this.quitItem.Caption = "退出";
            this.quitItem.Id = 12;
            this.quitItem.Name = "quitItem";
            this.quitItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.quitItem_ItemClick);
            // 
            // editMenu
            // 
            this.editMenu.Caption = "编辑(E)";
            this.editMenu.Id = 13;
            this.editMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.revocationItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.redoItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.cutItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.copyItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.pasteItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.selectItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.findItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.findNextItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.replaceItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.sortItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem4)});
            this.editMenu.Name = "editMenu";
            // 
            // revocationItem
            // 
            this.revocationItem.Caption = "撤销(&U)";
            this.revocationItem.Id = 14;
            this.revocationItem.Name = "revocationItem";
            this.revocationItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.revocationItem_ItemClick);
            // 
            // redoItem
            // 
            this.redoItem.Caption = "重做(R)";
            this.redoItem.Id = 15;
            this.redoItem.Name = "redoItem";
            this.redoItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.redoItem_ItemClick);
            // 
            // cutItem
            // 
            this.cutItem.Caption = "剪切(&T)";
            this.cutItem.Id = 16;
            this.cutItem.Name = "cutItem";
            // 
            // copyItem
            // 
            this.copyItem.Caption = "复制(C)";
            this.copyItem.Id = 17;
            this.copyItem.Name = "copyItem";
            // 
            // pasteItem
            // 
            this.pasteItem.Caption = "粘贴(P)";
            this.pasteItem.Id = 18;
            this.pasteItem.Name = "pasteItem";
            // 
            // selectItem
            // 
            this.selectItem.Caption = "全选(&S)";
            this.selectItem.Id = 19;
            this.selectItem.Name = "selectItem";
            // 
            // findItem
            // 
            this.findItem.Caption = "查找(&F)";
            this.findItem.Id = 20;
            this.findItem.Name = "findItem";
            this.findItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.findItem_ItemClick);
            // 
            // findNextItem
            // 
            this.findNextItem.Caption = "查找下一个(F)";
            this.findNextItem.Id = 21;
            this.findNextItem.Name = "findNextItem";
            // 
            // replaceItem
            // 
            this.replaceItem.Caption = "替换(R)";
            this.replaceItem.Id = 22;
            this.replaceItem.Name = "replaceItem";
            this.replaceItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.replaceItem_ItemClick);
            // 
            // sortItem
            // 
            this.sortItem.Caption = "排序";
            this.sortItem.Id = 23;
            this.sortItem.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.sortByStartTimeItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.sortByEndTimeItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.sortByContentItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.sortByLengthItem)});
            this.sortItem.Name = "sortItem";
            // 
            // sortByStartTimeItem
            // 
            this.sortByStartTimeItem.Caption = "按开始时间";
            this.sortByStartTimeItem.Id = 24;
            this.sortByStartTimeItem.Name = "sortByStartTimeItem";
            // 
            // sortByEndTimeItem
            // 
            this.sortByEndTimeItem.Caption = "按结束时间";
            this.sortByEndTimeItem.Id = 25;
            this.sortByEndTimeItem.Name = "sortByEndTimeItem";
            // 
            // sortByContentItem
            // 
            this.sortByContentItem.Caption = "按内容";
            this.sortByContentItem.Id = 26;
            this.sortByContentItem.Name = "sortByContentItem";
            // 
            // sortByLengthItem
            // 
            this.sortByLengthItem.Caption = "按字符长度";
            this.sortByLengthItem.Id = 27;
            this.sortByLengthItem.Name = "sortByLengthItem";
            // 
            // barSubItem4
            // 
            this.barSubItem4.Caption = "标记";
            this.barSubItem4.Id = 28;
            this.barSubItem4.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem25),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem26),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem27)});
            this.barSubItem4.Name = "barSubItem4";
            // 
            // barButtonItem25
            // 
            this.barButtonItem25.Caption = "标记";
            this.barButtonItem25.Id = 29;
            this.barButtonItem25.Name = "barButtonItem25";
            // 
            // barButtonItem26
            // 
            this.barButtonItem26.Caption = "跳转到标记";
            this.barButtonItem26.Id = 30;
            this.barButtonItem26.Name = "barButtonItem26";
            // 
            // barButtonItem27
            // 
            this.barButtonItem27.Caption = "跳转到下一个标记";
            this.barButtonItem27.Id = 31;
            this.barButtonItem27.Name = "barButtonItem27";
            // 
            // subtitleMenu
            // 
            this.subtitleMenu.Caption = "字幕(I)";
            this.subtitleMenu.Id = 32;
            this.subtitleMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.addOneLineItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.addMutiLineItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.customSplitItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.combineLineItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.subtitleCombineItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.deleteItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.delete2Item),
            new DevExpress.XtraBars.LinkPersistInfo(this.clearTimeItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.clearContentItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.translationTimeItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.alignNowTimeItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.to23FPSItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.to25FPSItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.extendShowItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.changeUpandDownItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.lastLineItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.nextLineItem)});
            this.subtitleMenu.Name = "subtitleMenu";
            // 
            // addOneLineItem
            // 
            this.addOneLineItem.Caption = "插入单行字幕";
            this.addOneLineItem.Id = 33;
            this.addOneLineItem.Name = "addOneLineItem";
            this.addOneLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.addOneLineItem_ItemClick);
            // 
            // addMutiLineItem
            // 
            this.addMutiLineItem.Caption = "插入多行字幕";
            this.addMutiLineItem.Id = 34;
            this.addMutiLineItem.Name = "addMutiLineItem";
            this.addMutiLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.addMutiLineItem_ItemClick);
            // 
            // customSplitItem
            // 
            this.customSplitItem.Caption = "自定义拆分";
            this.customSplitItem.Id = 35;
            this.customSplitItem.Name = "customSplitItem";
            // 
            // combineLineItem
            // 
            this.combineLineItem.Caption = "行合并";
            this.combineLineItem.Id = 36;
            this.combineLineItem.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.combineOneLineItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.combineMutiLineItem)});
            this.combineLineItem.Name = "combineLineItem";
            // 
            // combineOneLineItem
            // 
            this.combineOneLineItem.Caption = "合并为单行显示";
            this.combineOneLineItem.Id = 50;
            this.combineOneLineItem.Name = "combineOneLineItem";
            this.combineOneLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.combineOneLineItem_ItemClick);
            // 
            // combineMutiLineItem
            // 
            this.combineMutiLineItem.Caption = "合并为多行显示";
            this.combineMutiLineItem.Id = 51;
            this.combineMutiLineItem.Name = "combineMutiLineItem";
            this.combineMutiLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.combineMutiLineItem_ItemClick);
            // 
            // subtitleCombineItem
            // 
            this.subtitleCombineItem.Caption = "字幕行合并为单行";
            this.subtitleCombineItem.Id = 37;
            this.subtitleCombineItem.Name = "subtitleCombineItem";
            this.subtitleCombineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.subtitleCombineItem_ItemClick);
            // 
            // deleteItem
            // 
            this.deleteItem.Caption = "删除";
            this.deleteItem.Id = 38;
            this.deleteItem.Name = "deleteItem";
            // 
            // delete2Item
            // 
            this.delete2Item.Caption = "删除...";
            this.delete2Item.Id = 39;
            this.delete2Item.Name = "delete2Item";
            // 
            // clearTimeItem
            // 
            this.clearTimeItem.Caption = "时间清零";
            this.clearTimeItem.Id = 40;
            this.clearTimeItem.Name = "clearTimeItem";
            // 
            // clearContentItem
            // 
            this.clearContentItem.Caption = "内容清空";
            this.clearContentItem.Id = 41;
            this.clearContentItem.Name = "clearContentItem";
            // 
            // translationTimeItem
            // 
            this.translationTimeItem.Caption = "平移时间";
            this.translationTimeItem.Id = 42;
            this.translationTimeItem.Name = "translationTimeItem";
            this.translationTimeItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.translationTimeItem_ItemClick);
            // 
            // alignNowTimeItem
            // 
            this.alignNowTimeItem.Caption = "对其到当前播放时间";
            this.alignNowTimeItem.Id = 43;
            this.alignNowTimeItem.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.autoModeItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.nextItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.nowLineStartItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.nowLineEndItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.onlyNowLineItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.afterNowLineItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.allLineItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.lastSignItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.alignLineItem)});
            this.alignNowTimeItem.Name = "alignNowTimeItem";
            // 
            // autoModeItem
            // 
            this.autoModeItem.Caption = "自动模式";
            this.autoModeItem.Id = 109;
            this.autoModeItem.Name = "autoModeItem";
            this.autoModeItem.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.autoModeItem_CheckedChanged);
            // 
            // nextItem
            // 
            this.nextItem.Caption = "下一个";
            this.nextItem.Id = 53;
            this.nextItem.Name = "nextItem";
            this.nextItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.nextItem_ItemClick);
            // 
            // nowLineStartItem
            // 
            this.nowLineStartItem.Caption = "当前行的开始";
            this.nowLineStartItem.Id = 54;
            this.nowLineStartItem.Name = "nowLineStartItem";
            this.nowLineStartItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.nowLineStartItem_ItemClick);
            // 
            // nowLineEndItem
            // 
            this.nowLineEndItem.Caption = "当前行的结束";
            this.nowLineEndItem.Id = 55;
            this.nowLineEndItem.Name = "nowLineEndItem";
            this.nowLineEndItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.nowLineEndItem_ItemClick);
            // 
            // onlyNowLineItem
            // 
            this.onlyNowLineItem.Caption = "仅当前行";
            this.onlyNowLineItem.Id = 56;
            this.onlyNowLineItem.Name = "onlyNowLineItem";
            this.onlyNowLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.onlyNowLineItem_ItemClick);
            // 
            // afterNowLineItem
            // 
            this.afterNowLineItem.Caption = "当前行之后";
            this.afterNowLineItem.Id = 57;
            this.afterNowLineItem.Name = "afterNowLineItem";
            this.afterNowLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.afterNowLineItem_ItemClick);
            // 
            // allLineItem
            // 
            this.allLineItem.Caption = "所有行";
            this.allLineItem.Id = 58;
            this.allLineItem.Name = "allLineItem";
            this.allLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allLineItem_ItemClick);
            // 
            // lastSignItem
            // 
            this.lastSignItem.Caption = "至上一个标记";
            this.lastSignItem.Id = 59;
            this.lastSignItem.Name = "lastSignItem";
            this.lastSignItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.lastSignItem_ItemClick);
            // 
            // alignLineItem
            // 
            this.alignLineItem.Caption = "前后标记中对其";
            this.alignLineItem.Id = 60;
            this.alignLineItem.Name = "alignLineItem";
            this.alignLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.alignLineItem_ItemClick);
            // 
            // to23FPSItem
            // 
            this.to23FPSItem.Caption = "25FPS转换为23.976FPS";
            this.to23FPSItem.Id = 44;
            this.to23FPSItem.Name = "to23FPSItem";
            // 
            // to25FPSItem
            // 
            this.to25FPSItem.Caption = "23.976FPS转换为25FPS";
            this.to25FPSItem.Id = 45;
            this.to25FPSItem.Name = "to25FPSItem";
            // 
            // extendShowItem
            // 
            this.extendShowItem.Caption = "延长显示";
            this.extendShowItem.Id = 46;
            this.extendShowItem.Name = "extendShowItem";
            this.extendShowItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.extendShowItem_ItemClick);
            // 
            // changeUpandDownItem
            // 
            this.changeUpandDownItem.Caption = "交换上下行";
            this.changeUpandDownItem.Id = 47;
            this.changeUpandDownItem.Name = "changeUpandDownItem";
            this.changeUpandDownItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.changeUpandDownItem_ItemClick);
            // 
            // lastLineItem
            // 
            this.lastLineItem.Caption = "上一行";
            this.lastLineItem.Id = 48;
            this.lastLineItem.Name = "lastLineItem";
            // 
            // nextLineItem
            // 
            this.nextLineItem.Caption = "下一行";
            this.nextLineItem.Id = 49;
            this.nextLineItem.Name = "nextLineItem";
            // 
            // toolMenu
            // 
            this.toolMenu.Caption = "工具(&T)";
            this.toolMenu.Id = 61;
            this.toolMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.ccSubtitleHandleItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.ccRemoveDuplicateItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.ccRemoveDuplicateItemL),
            new DevExpress.XtraBars.LinkPersistInfo(this.merageAccurateLineItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.twoLanMerageItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.addEditorItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.compareSubtitleItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.findErrorItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.createEngNameItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.replaceEngNameItem)});
            this.toolMenu.Name = "toolMenu";
            // 
            // ccSubtitleHandleItem
            // 
            this.ccSubtitleHandleItem.Caption = "CC字幕处理";
            this.ccSubtitleHandleItem.Id = 62;
            this.ccSubtitleHandleItem.Name = "ccSubtitleHandleItem";
            this.ccSubtitleHandleItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ccSubtitleHandleItem_ItemClick);
            // 
            // ccRemoveDuplicateItem
            // 
            this.ccRemoveDuplicateItem.Caption = "CC字幕去重【横向】";
            this.ccRemoveDuplicateItem.Id = 63;
            this.ccRemoveDuplicateItem.Name = "ccRemoveDuplicateItem";
            this.ccRemoveDuplicateItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ccRemoveDuplicateItem_ItemClick);
            // 
            // ccRemoveDuplicateItemL
            // 
            this.ccRemoveDuplicateItemL.Caption = "CC字幕去重【纵向】";
            this.ccRemoveDuplicateItemL.Id = 106;
            this.ccRemoveDuplicateItemL.Name = "ccRemoveDuplicateItemL";
            this.ccRemoveDuplicateItemL.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.ccRemoveDuplicateItemL_ItemClick);
            // 
            // merageAccurateLineItem
            // 
            this.merageAccurateLineItem.Caption = "合并精轴";
            this.merageAccurateLineItem.Id = 64;
            this.merageAccurateLineItem.Name = "merageAccurateLineItem";
            this.merageAccurateLineItem.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.merageAccurateLineItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.merageAccurateLineItem_ItemClick);
            // 
            // twoLanMerageItem
            // 
            this.twoLanMerageItem.Caption = "双语字幕合并";
            this.twoLanMerageItem.Id = 65;
            this.twoLanMerageItem.Name = "twoLanMerageItem";
            this.twoLanMerageItem.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // addEditorItem
            // 
            this.addEditorItem.Caption = "添加制作人员";
            this.addEditorItem.Id = 66;
            this.addEditorItem.Name = "addEditorItem";
            this.addEditorItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.addEditorItem_ItemClick);
            // 
            // compareSubtitleItem
            // 
            this.compareSubtitleItem.Caption = "字幕对比";
            this.compareSubtitleItem.Id = 67;
            this.compareSubtitleItem.Name = "compareSubtitleItem";
            // 
            // findErrorItem
            // 
            this.findErrorItem.Caption = "检查除错";
            this.findErrorItem.Id = 68;
            this.findErrorItem.Name = "findErrorItem";
            this.findErrorItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.findErrorItem_ItemClick);
            // 
            // createEngNameItem
            // 
            this.createEngNameItem.Caption = "生成英文名列表";
            this.createEngNameItem.Id = 69;
            this.createEngNameItem.Name = "createEngNameItem";
            this.createEngNameItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.createEngNameItem_ItemClick);
            // 
            // replaceEngNameItem
            // 
            this.replaceEngNameItem.Caption = "执行英文名替换";
            this.replaceEngNameItem.Id = 70;
            this.replaceEngNameItem.Name = "replaceEngNameItem";
            this.replaceEngNameItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.replaceEngNameItem_ItemClick);
            // 
            // videoMenu
            // 
            this.videoMenu.Caption = "视频(&V)";
            this.videoMenu.Id = 71;
            this.videoMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.openVideoItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.pauseVideoItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.stopVideoItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.forwardOneSecItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.backOneSecItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.forward5SecItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.back5SecItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItemOneFrame),
            new DevExpress.XtraBars.LinkPersistInfo(this.subSyncItem, true)});
            this.videoMenu.Name = "videoMenu";
            // 
            // openVideoItem
            // 
            this.openVideoItem.Caption = "打开";
            this.openVideoItem.Id = 72;
            this.openVideoItem.Name = "openVideoItem";
            this.openVideoItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.openVideoItem_ItemClick);
            // 
            // pauseVideoItem
            // 
            this.pauseVideoItem.Caption = "播放/暂停";
            this.pauseVideoItem.Id = 73;
            this.pauseVideoItem.Name = "pauseVideoItem";
            this.pauseVideoItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.pauseVideoItem_ItemClick);
            // 
            // stopVideoItem
            // 
            this.stopVideoItem.Caption = "停止";
            this.stopVideoItem.Id = 74;
            this.stopVideoItem.Name = "stopVideoItem";
            this.stopVideoItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.stopVideoItem_ItemClick);
            // 
            // forwardOneSecItem
            // 
            this.forwardOneSecItem.Caption = "前进1秒";
            this.forwardOneSecItem.Id = 75;
            this.forwardOneSecItem.Name = "forwardOneSecItem";
            this.forwardOneSecItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.forwardOneSecItem_ItemClick);
            // 
            // backOneSecItem
            // 
            this.backOneSecItem.Caption = "后退1秒";
            this.backOneSecItem.Id = 76;
            this.backOneSecItem.Name = "backOneSecItem";
            this.backOneSecItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.backOneSecItem_ItemClick);
            // 
            // forward5SecItem
            // 
            this.forward5SecItem.Caption = "前进5秒";
            this.forward5SecItem.Id = 77;
            this.forward5SecItem.Name = "forward5SecItem";
            this.forward5SecItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.forward5SecItem_ItemClick);
            // 
            // back5SecItem
            // 
            this.back5SecItem.Caption = "后退5秒";
            this.back5SecItem.Id = 78;
            this.back5SecItem.Name = "back5SecItem";
            this.back5SecItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.back5SecItem_ItemClick);
            // 
            // barButtonItemOneFrame
            // 
            this.barButtonItemOneFrame.Caption = "前进一帧";
            this.barButtonItemOneFrame.Id = 79;
            this.barButtonItemOneFrame.Name = "barButtonItemOneFrame";
            this.barButtonItemOneFrame.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItemOneFrame_ItemClick);
            // 
            // subSyncItem
            // 
            this.subSyncItem.Caption = "字幕同步";
            this.subSyncItem.Id = 108;
            this.subSyncItem.Name = "subSyncItem";
            this.subSyncItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.subSyncItem_ItemClick);
            this.subSyncItem.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.subSyncItem_CheckedChanged);
            // 
            // optionMenu
            // 
            this.optionMenu.Caption = "设置(&S)";
            this.optionMenu.Id = 81;
            this.optionMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.softwareOptionItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.viewOptionItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.hideEffectsItem, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.saveAutoItem)});
            this.optionMenu.Name = "optionMenu";
            // 
            // softwareOptionItem
            // 
            this.softwareOptionItem.Caption = "软件选项(&D)";
            this.softwareOptionItem.Id = 82;
            this.softwareOptionItem.Name = "softwareOptionItem";
            // 
            // viewOptionItem
            // 
            this.viewOptionItem.Caption = "设置查看SSA/ASS";
            this.viewOptionItem.Id = 83;
            this.viewOptionItem.Name = "viewOptionItem";
            // 
            // hideEffectsItem
            // 
            this.hideEffectsItem.Caption = "隐藏特效代码";
            this.hideEffectsItem.Id = 86;
            this.hideEffectsItem.Name = "hideEffectsItem";
            // 
            // saveAutoItem
            // 
            this.saveAutoItem.Caption = "自动保存";
            this.saveAutoItem.Id = 88;
            this.saveAutoItem.Name = "saveAutoItem";
            // 
            // publishMenu
            // 
            this.publishMenu.Caption = "字幕发布站(&P)";
            this.publishMenu.Id = 89;
            this.publishMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem74)});
            this.publishMenu.Name = "publishMenu";
            // 
            // barButtonItem74
            // 
            this.barButtonItem74.Caption = "人人影视";
            this.barButtonItem74.Id = 90;
            this.barButtonItem74.Name = "barButtonItem74";
            // 
            // viewMenu
            // 
            this.viewMenu.Caption = "视图(&V)";
            this.viewMenu.Id = 92;
            this.viewMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.toolsSelectedItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.statusItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem15)});
            this.viewMenu.Name = "viewMenu";
            // 
            // toolsSelectedItem
            // 
            this.toolsSelectedItem.Caption = "工具栏和停靠窗口";
            this.toolsSelectedItem.Id = 94;
            this.toolsSelectedItem.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem4),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem5),
            new DevExpress.XtraBars.LinkPersistInfo(this.barCheckItem6),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem75, true)});
            this.toolsSelectedItem.Name = "toolsSelectedItem";
            // 
            // barCheckItem4
            // 
            this.barCheckItem4.Caption = "Tasks Pane";
            this.barCheckItem4.Id = 96;
            this.barCheckItem4.Name = "barCheckItem4";
            // 
            // barCheckItem5
            // 
            this.barCheckItem5.Caption = "字幕编辑窗口";
            this.barCheckItem5.Id = 97;
            this.barCheckItem5.Name = "barCheckItem5";
            // 
            // barCheckItem6
            // 
            this.barCheckItem6.Caption = "视频播放";
            this.barCheckItem6.Id = 98;
            this.barCheckItem6.Name = "barCheckItem6";
            // 
            // barButtonItem75
            // 
            this.barButtonItem75.Caption = "自定义";
            this.barButtonItem75.Id = 99;
            this.barButtonItem75.Name = "barButtonItem75";
            // 
            // statusItem
            // 
            this.statusItem.Caption = "状态栏";
            this.statusItem.Id = 95;
            this.statusItem.Name = "statusItem";
            // 
            // barSubItem15
            // 
            this.barSubItem15.Caption = "应用程序外观";
            this.barSubItem15.Id = 100;
            this.barSubItem15.Name = "barSubItem15";
            // 
            // helpMenu
            // 
            this.helpMenu.Caption = "帮助(&H)";
            this.helpMenu.Id = 93;
            this.helpMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem76),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem77),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem78, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem79),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem80, true)});
            this.helpMenu.Name = "helpMenu";
            // 
            // barButtonItem76
            // 
            this.barButtonItem76.Caption = "YYeTs人人影视网站";
            this.barButtonItem76.Id = 101;
            this.barButtonItem76.Name = "barButtonItem76";
            // 
            // barButtonItem77
            // 
            this.barButtonItem77.Caption = "意见反馈";
            this.barButtonItem77.Id = 102;
            this.barButtonItem77.Name = "barButtonItem77";
            // 
            // barButtonItem78
            // 
            this.barButtonItem78.Caption = "使用教程";
            this.barButtonItem78.Id = 103;
            this.barButtonItem78.Name = "barButtonItem78";
            // 
            // barButtonItem79
            // 
            this.barButtonItem79.Caption = "检查更新";
            this.barButtonItem79.Id = 104;
            this.barButtonItem79.Name = "barButtonItem79";
            // 
            // barButtonItem80
            // 
            this.barButtonItem80.Caption = "关于Time Machine(&A)";
            this.barButtonItem80.Id = 105;
            this.barButtonItem80.Name = "barButtonItem80";
            // 
            // bar3
            // 
            this.bar3.BarName = "Status bar";
            this.bar3.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.bar3.DockCol = 0;
            this.bar3.DockRow = 0;
            this.bar3.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.bar3.OptionsBar.AllowQuickCustomization = false;
            this.bar3.OptionsBar.DrawDragBorder = false;
            this.bar3.OptionsBar.UseWholeRow = true;
            this.bar3.Text = "Status bar";
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(1186, 24);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 575);
            this.barDockControlBottom.Size = new System.Drawing.Size(1186, 23);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 24);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 551);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1186, 24);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 551);
            // 
            // textTimeLinePanel
            // 
            this.textTimeLinePanel.Controls.Add(this.listView1);
            this.textTimeLinePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textTimeLinePanel.Location = new System.Drawing.Point(131, 439);
            this.textTimeLinePanel.Name = "textTimeLinePanel";
            this.textTimeLinePanel.Size = new System.Drawing.Size(1055, 136);
            this.textTimeLinePanel.TabIndex = 4;
            this.textTimeLinePanel.Text = "所有时间轴";
            // 
            // listView1
            // 
            this.listView1.ColumnToSort = 0;
            this.listView1.ContextMenuStrip = this.listViewMenu;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.listView1.FullRowSelect = true;
            this.listView1.Location = new System.Drawing.Point(2, 23);
            this.listView1.Name = "listView1";
            this.listView1.Order = System.Windows.Forms.SortOrder.None;
            this.listView1.OwnerDraw = true;
            this.listView1.Size = new System.Drawing.Size(1051, 111);
            this.listView1.SmallImageList = this.imageList2;
            this.listView1.SortStyle = 0;
            this.listView1.StateImageList = this.imageList2;
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.VirtualMode = true;
            this.listView1.ItemActivate += new System.EventHandler(this.listView1_ItemActivate);
            this.listView1.DoubleClickAction += new TimeMDev.DDoubleClickAction(this.listView1_DoubleClickAction);
            this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
            this.listView1.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.listView1_ItemSelectionChanged);
            // 
            // listViewMenu
            // 
            this.listViewMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addOneLineContext,
            this.addMutiLineContext,
            this.moveTimeContext,
            this.alignNowLineContext,
            this.alignAfterLineContext,
            this.alignAllLineContext,
            this.toolStripSeparator1,
            this.customSpiltContext,
            this.combineOneLineContext,
            this.combineMutiLineContext,
            this.toolStripSeparator2,
            this.deleteLineContext,
            this.zeroTime,
            this.zeroContentContext,
            this.toolStripSeparator3,
            this.undoContext,
            this.repeatContext,
            this.toolStripSeparator4,
            this.cutContext,
            this.copyContext,
            this.pasteContext,
            this.checkAllContext});
            this.listViewMenu.Name = "listViewMenu";
            this.listViewMenu.Size = new System.Drawing.Size(229, 424);
            this.listViewMenu.Opening += new System.ComponentModel.CancelEventHandler(this.listViewMenu_Opening);
            // 
            // addOneLineContext
            // 
            this.addOneLineContext.Name = "addOneLineContext";
            this.addOneLineContext.Size = new System.Drawing.Size(228, 22);
            this.addOneLineContext.Text = "插入单行字幕";
            this.addOneLineContext.Click += new System.EventHandler(this.addOneLineContext_Click);
            // 
            // addMutiLineContext
            // 
            this.addMutiLineContext.Name = "addMutiLineContext";
            this.addMutiLineContext.Size = new System.Drawing.Size(228, 22);
            this.addMutiLineContext.Text = "插入多行字幕";
            this.addMutiLineContext.Click += new System.EventHandler(this.addMutiLineContext_Click);
            // 
            // moveTimeContext
            // 
            this.moveTimeContext.Name = "moveTimeContext";
            this.moveTimeContext.Size = new System.Drawing.Size(228, 22);
            this.moveTimeContext.Text = "平移时间";
            // 
            // alignNowLineContext
            // 
            this.alignNowLineContext.Name = "alignNowLineContext";
            this.alignNowLineContext.Size = new System.Drawing.Size(228, 22);
            this.alignNowLineContext.Text = "对其播放器时间(当前行)";
            // 
            // alignAfterLineContext
            // 
            this.alignAfterLineContext.Name = "alignAfterLineContext";
            this.alignAfterLineContext.Size = new System.Drawing.Size(228, 22);
            this.alignAfterLineContext.Text = "对其播放器时间(当前行以后)";
            // 
            // alignAllLineContext
            // 
            this.alignAllLineContext.Name = "alignAllLineContext";
            this.alignAllLineContext.Size = new System.Drawing.Size(228, 22);
            this.alignAllLineContext.Text = "对其所有行";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(225, 6);
            // 
            // customSpiltContext
            // 
            this.customSpiltContext.Name = "customSpiltContext";
            this.customSpiltContext.Size = new System.Drawing.Size(228, 22);
            this.customSpiltContext.Text = "自定义拆分";
            this.customSpiltContext.Click += new System.EventHandler(this.customSpiltContext_Click);
            // 
            // combineOneLineContext
            // 
            this.combineOneLineContext.Name = "combineOneLineContext";
            this.combineOneLineContext.Size = new System.Drawing.Size(228, 22);
            this.combineOneLineContext.Text = "合并为单行显示";
            this.combineOneLineContext.Click += new System.EventHandler(this.combineOneLineContext_Click);
            // 
            // combineMutiLineContext
            // 
            this.combineMutiLineContext.Name = "combineMutiLineContext";
            this.combineMutiLineContext.Size = new System.Drawing.Size(228, 22);
            this.combineMutiLineContext.Text = "合并为多行显示";
            this.combineMutiLineContext.Click += new System.EventHandler(this.combineMutiLineContext_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(225, 6);
            // 
            // deleteLineContext
            // 
            this.deleteLineContext.Name = "deleteLineContext";
            this.deleteLineContext.Size = new System.Drawing.Size(228, 22);
            this.deleteLineContext.Text = "删除行";
            this.deleteLineContext.Click += new System.EventHandler(this.deleteLineContext_Click);
            // 
            // zeroTime
            // 
            this.zeroTime.Name = "zeroTime";
            this.zeroTime.Size = new System.Drawing.Size(228, 22);
            this.zeroTime.Text = "仅时间清零";
            this.zeroTime.Click += new System.EventHandler(this.zeroTime_Click);
            // 
            // zeroContentContext
            // 
            this.zeroContentContext.Name = "zeroContentContext";
            this.zeroContentContext.Size = new System.Drawing.Size(228, 22);
            this.zeroContentContext.Text = "仅内容清空";
            this.zeroContentContext.Click += new System.EventHandler(this.zeroContentContext_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(225, 6);
            // 
            // undoContext
            // 
            this.undoContext.Name = "undoContext";
            this.undoContext.Size = new System.Drawing.Size(228, 22);
            this.undoContext.Text = "撤销";
            this.undoContext.Click += new System.EventHandler(this.undoContext_Click);
            // 
            // repeatContext
            // 
            this.repeatContext.Name = "repeatContext";
            this.repeatContext.Size = new System.Drawing.Size(228, 22);
            this.repeatContext.Text = "重做";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(225, 6);
            // 
            // cutContext
            // 
            this.cutContext.Name = "cutContext";
            this.cutContext.Size = new System.Drawing.Size(228, 22);
            this.cutContext.Text = "剪切";
            this.cutContext.Click += new System.EventHandler(this.cutContext_Click);
            // 
            // copyContext
            // 
            this.copyContext.Name = "copyContext";
            this.copyContext.Size = new System.Drawing.Size(228, 22);
            this.copyContext.Text = "复制";
            this.copyContext.Click += new System.EventHandler(this.copyContext_Click);
            // 
            // pasteContext
            // 
            this.pasteContext.Name = "pasteContext";
            this.pasteContext.Size = new System.Drawing.Size(228, 22);
            this.pasteContext.Text = "粘贴";
            this.pasteContext.Click += new System.EventHandler(this.pasteContext_Click);
            // 
            // checkAllContext
            // 
            this.checkAllContext.Name = "checkAllContext";
            this.checkAllContext.Size = new System.Drawing.Size(228, 22);
            this.checkAllContext.Text = "全选";
            this.checkAllContext.Click += new System.EventHandler(this.checkAllContext_Click);
            // 
            // imageList2
            // 
            this.imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList2.ImageSize = new System.Drawing.Size(255, 50);
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1186, 598);
            this.Controls.Add(this.textTimeLinePanel);
            this.Controls.Add(this.picTimeLinePanel);
            this.Controls.Add(this.panelContainer1);
            this.Controls.Add(this.dockPanel1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).EndInit();
            this.dockPanel1.ResumeLayout(false);
            this.dockPanel1_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).EndInit();
            this.panelContainer1.ResumeLayout(false);
            this.videoPanel.ResumeLayout(false);
            this.dockPanel3_Container.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.movieTrack)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.toolStripPanel1.ResumeLayout(false);
            this.toolStripPanel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.modifySubtitlePanel.ResumeLayout(false);
            this.dockPanel4_Container.ResumeLayout(false);
            this.dockPanel4_Container.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.picTimeLinePanel.ResumeLayout(false);
            this.dockPanel2_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rateShow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textTimeLinePanel)).EndInit();
            this.textTimeLinePanel.ResumeLayout(false);
            this.listViewMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.Bar bar3;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraEditors.GroupControl textTimeLinePanel;
        private DevExpress.XtraBars.Docking.DockPanel picTimeLinePanel;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel2_Container;
        private DevExpress.XtraBars.Docking.DockPanel videoPanel;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel3_Container;
        private DevExpress.XtraBars.Docking.DockPanel modifySubtitlePanel;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel4_Container;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel1;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        private DevExpress.XtraBars.BarSubItem fileMenu;
        private DevExpress.XtraBars.BarButtonItem newSubtitleItem;
        private DevExpress.XtraBars.BarButtonItem loadSubtitleItem;
        private DevExpress.XtraBars.BarButtonItem loadTranslationItem;
        private DevExpress.XtraBars.BarButtonItem addSubtitleItem;
        private DevExpress.XtraBars.BarButtonItem saveSubtitleItem;
        private DevExpress.XtraBars.BarButtonItem saveAsItem;
        private DevExpress.XtraBars.BarButtonItem fileSplitSaveItem;
        private DevExpress.XtraBars.BarButtonItem saveAsMacUTF8Item;
        private DevExpress.XtraBars.BarButtonItem exportMutiSaveItem;
        private DevExpress.XtraBars.BarButtonItem closeItem;
        private DevExpress.XtraBars.BarButtonItem quitItem;
        private DevExpress.XtraBars.BarSubItem editMenu;
        private DevExpress.XtraBars.BarButtonItem revocationItem;
        private DevExpress.XtraBars.BarButtonItem redoItem;
        private DevExpress.XtraBars.BarButtonItem cutItem;
        private DevExpress.XtraBars.BarButtonItem copyItem;
        private DevExpress.XtraBars.BarButtonItem pasteItem;
        private DevExpress.XtraBars.BarButtonItem selectItem;
        private DevExpress.XtraBars.BarButtonItem findItem;
        private DevExpress.XtraBars.BarButtonItem findNextItem;
        private DevExpress.XtraBars.BarButtonItem replaceItem;
        private DevExpress.XtraBars.BarSubItem sortItem;
        private DevExpress.XtraBars.BarButtonItem sortByStartTimeItem;
        private DevExpress.XtraBars.BarButtonItem sortByEndTimeItem;
        private DevExpress.XtraBars.BarButtonItem sortByContentItem;
        private DevExpress.XtraBars.BarButtonItem sortByLengthItem;
        private DevExpress.XtraBars.BarSubItem barSubItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem25;
        private DevExpress.XtraBars.BarButtonItem barButtonItem26;
        private DevExpress.XtraBars.BarButtonItem barButtonItem27;
        private DevExpress.XtraBars.BarSubItem subtitleMenu;
        private DevExpress.XtraBars.BarButtonItem addOneLineItem;
        private DevExpress.XtraBars.BarButtonItem addMutiLineItem;
        private DevExpress.XtraBars.BarButtonItem customSplitItem;
        private DevExpress.XtraBars.BarSubItem combineLineItem;
        private DevExpress.XtraBars.BarButtonItem subtitleCombineItem;
        private DevExpress.XtraBars.BarButtonItem deleteItem;
        private DevExpress.XtraBars.BarButtonItem delete2Item;
        private DevExpress.XtraBars.BarButtonItem clearTimeItem;
        private DevExpress.XtraBars.BarButtonItem clearContentItem;
        private DevExpress.XtraBars.BarButtonItem translationTimeItem;
        private DevExpress.XtraBars.BarSubItem alignNowTimeItem;
        private DevExpress.XtraBars.BarButtonItem to23FPSItem;
        private DevExpress.XtraBars.BarButtonItem to25FPSItem;
        private DevExpress.XtraBars.BarButtonItem extendShowItem;
        private DevExpress.XtraBars.BarButtonItem changeUpandDownItem;
        private DevExpress.XtraBars.BarButtonItem lastLineItem;
        private DevExpress.XtraBars.BarButtonItem nextLineItem;
        private DevExpress.XtraBars.BarButtonItem combineOneLineItem;
        private DevExpress.XtraBars.BarButtonItem combineMutiLineItem;
        private DevExpress.XtraBars.BarButtonItem nextItem;
        private DevExpress.XtraBars.BarButtonItem nowLineStartItem;
        private DevExpress.XtraBars.BarButtonItem nowLineEndItem;
        private DevExpress.XtraBars.BarButtonItem onlyNowLineItem;
        private DevExpress.XtraBars.BarButtonItem afterNowLineItem;
        private DevExpress.XtraBars.BarButtonItem allLineItem;
        private DevExpress.XtraBars.BarButtonItem lastSignItem;
        private DevExpress.XtraBars.BarButtonItem alignLineItem;
        private DevExpress.XtraBars.BarSubItem toolMenu;
        private DevExpress.XtraBars.BarButtonItem ccSubtitleHandleItem;
        private DevExpress.XtraBars.BarButtonItem ccRemoveDuplicateItem;
        private DevExpress.XtraBars.BarButtonItem merageAccurateLineItem;
        private DevExpress.XtraBars.BarButtonItem twoLanMerageItem;
        private DevExpress.XtraBars.BarButtonItem addEditorItem;
        private DevExpress.XtraBars.BarButtonItem compareSubtitleItem;
        private DevExpress.XtraBars.BarButtonItem findErrorItem;
        private DevExpress.XtraBars.BarButtonItem createEngNameItem;
        private DevExpress.XtraBars.BarButtonItem replaceEngNameItem;
        private DevExpress.XtraBars.BarSubItem videoMenu;
        private DevExpress.XtraBars.BarButtonItem openVideoItem;
        private DevExpress.XtraBars.BarButtonItem pauseVideoItem;
        private DevExpress.XtraBars.BarButtonItem stopVideoItem;
        private DevExpress.XtraBars.BarButtonItem forwardOneSecItem;
        private DevExpress.XtraBars.BarButtonItem backOneSecItem;
        private DevExpress.XtraBars.BarButtonItem forward5SecItem;
        private DevExpress.XtraBars.BarButtonItem back5SecItem;
        private DevExpress.XtraBars.BarButtonItem barButtonItemOneFrame;
        private DevExpress.XtraBars.BarSubItem optionMenu;
        private DevExpress.XtraBars.BarButtonItem softwareOptionItem;
        private DevExpress.XtraBars.BarButtonItem viewOptionItem;
        private DevExpress.XtraBars.BarCheckItem hideEffectsItem;
        private DevExpress.XtraBars.BarCheckItem saveAutoItem;
        private DevExpress.XtraBars.BarSubItem publishMenu;
        private DevExpress.XtraBars.BarButtonItem barButtonItem74;
        private DevExpress.XtraBars.BarSubItem viewMenu;
        private DevExpress.XtraBars.BarSubItem toolsSelectedItem;
        private DevExpress.XtraBars.BarCheckItem barCheckItem4;
        private DevExpress.XtraBars.BarCheckItem barCheckItem5;
        private DevExpress.XtraBars.BarCheckItem barCheckItem6;
        private DevExpress.XtraBars.BarCheckItem statusItem;
        private DevExpress.XtraBars.BarSubItem helpMenu;
        private DevExpress.XtraBars.BarButtonItem barButtonItem75;
        private DevExpress.XtraBars.BarSubItem barSubItem15;
        private DevExpress.XtraBars.BarButtonItem barButtonItem76;
        private DevExpress.XtraBars.BarButtonItem barButtonItem77;
        private DevExpress.XtraBars.BarButtonItem barButtonItem78;
        private DevExpress.XtraBars.BarButtonItem barButtonItem79;
        private DevExpress.XtraBars.BarButtonItem barButtonItem80;
        private DevExpress.XtraNavBar.NavBarControl navBarControl1;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup1;
        private DevExpress.XtraNavBar.NavBarItem openSubtitleLink;
        private DevExpress.XtraNavBar.NavBarItem openVideoLink;
        private DevExpress.XtraNavBar.NavBarItem newSubtitleLink;
        private DevExpress.XtraNavBar.NavBarItem loadTxtLink;
        private DevExpress.XtraNavBar.NavBarItem addSubtitleLink;
        private DevExpress.XtraNavBar.NavBarItem ccHandleLink;
        private DevExpress.XtraNavBar.NavBarItem exportSubtitleItem;
        private DevExpress.XtraNavBar.NavBarItem saveSubtitleLink;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup2;
        private DevExpress.XtraNavBar.NavBarItem merageToEndLink;
        private DevExpress.XtraNavBar.NavBarItem merageToNewLink;
        private DevExpress.XtraNavBar.NavBarItem cutLineLink;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup3;
        private DevExpress.XtraNavBar.NavBarItem alignNowLineLink;
        private DevExpress.XtraNavBar.NavBarItem alignNextLineLink;
        private DevExpress.XtraNavBar.NavBarItem alignAllLineLink;
        private DevExpress.XtraNavBar.NavBarItem alignToBeforeSignLink;
        private DevExpress.XtraNavBar.NavBarItem alignToAfterSignLink;
        private DevExpress.XtraNavBar.NavBarItem translationTimeLink;
        private DevExpress.XtraNavBar.NavBarItem mergeTwoLanLink;
        private DevExpress.XtraNavBar.NavBarItem findErrorLink;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup4;
        private DevExpress.XtraNavBar.NavBarItem startMplayerFristTimeLink;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ImageList imageList1;
        public System.Windows.Forms.PictureBox rateShow;
        private System.Windows.Forms.Panel videoPlayPanel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.TrackBar movieTrack;
        public System.Windows.Forms.Label nowTimeLineShow;
        public System.Windows.Forms.TextBox numEdit;
        public System.Windows.Forms.TextBox timeEditEnd;
        public System.Windows.Forms.TextBox timeEditStart;
        public System.Windows.Forms.TextBox contentEdit;
        public System.Windows.Forms.Button confirmChange;
        public System.Windows.Forms.Label nowTimeShow;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        public YYListView listView1;
        private System.Windows.Forms.ImageList imageList2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ContextMenuStrip listViewMenu;
        private System.Windows.Forms.ToolStripMenuItem addOneLineContext;
        private System.Windows.Forms.ToolStripMenuItem addMutiLineContext;
        private System.Windows.Forms.ToolStripMenuItem moveTimeContext;
        private System.Windows.Forms.ToolStripMenuItem alignNowLineContext;
        private System.Windows.Forms.ToolStripMenuItem alignAfterLineContext;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem customSpiltContext;
        private System.Windows.Forms.ToolStripMenuItem combineOneLineContext;
        private System.Windows.Forms.ToolStripMenuItem combineMutiLineContext;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem deleteLineContext;
        private System.Windows.Forms.ToolStripMenuItem zeroTime;
        private System.Windows.Forms.ToolStripMenuItem zeroContentContext;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem undoContext;
        private System.Windows.Forms.ToolStripMenuItem repeatContext;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem cutContext;
        private System.Windows.Forms.ToolStripMenuItem copyContext;
        private System.Windows.Forms.ToolStripMenuItem pasteContext;
        private System.Windows.Forms.ToolStripMenuItem checkAllContext;
        private System.Windows.Forms.ToolStripMenuItem alignAllLineContext;
        private DevExpress.XtraBars.BarButtonItem ccRemoveDuplicateItemL;
        private DevExpress.XtraBars.Docking.DockPanel panelContainer1;
        private System.Windows.Forms.ToolStripPanel toolStripPanel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripLoadFile;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripPlay;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolStripPause;
        private System.Windows.Forms.ToolStripButton toolStripBack5;
        private System.Windows.Forms.ToolStripButton toolStripForward5;
        private System.Windows.Forms.ToolStripButton toolStripBack10;
        private System.Windows.Forms.ToolStripButton toolStripForward10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton toolStrip1Step;
        private System.Windows.Forms.ToolStripButton toolStripSyn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton toolStripAlignNow;
        private System.Windows.Forms.ToolStripButton toolStripAlignAfter;
        private System.Windows.Forms.ToolStripButton toolStripAlighAll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton toolStripAlighStart;
        private System.Windows.Forms.ToolStripButton toolStripAlighEnd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripButton toolStripAddOne;
        private System.Windows.Forms.ToolStripButton toolStripAddMuti;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripButton toolStripSaveAuto;
        private System.Windows.Forms.ToolStripButton toolStripSign;
        private System.Windows.Forms.ToolStripButton toolStripSync;
        private DevExpress.XtraBars.BarCheckItem subSyncItem;
        private DevExpress.XtraBars.BarCheckItem autoModeItem;
    }
}

